
import React, { useState, useEffect, useRef } from 'react';
import { useCart } from '../hooks/useCart';
import { IRAQI_LOCATIONS, DELIVERY_FEE } from '../../config';
import { sendVerificationCode, verifyCode, submitOrder } from '../api';
import type { OrderDetails, Language } from '../types';
import { trackEvent } from '../analytics';
import { useToast } from '../hooks/useToast';


const GOVERNORATES = Object.keys(IRAQI_LOCATIONS);

// --- FOR DEVELOPMENT: Default checkout info for faster testing ---
const DEFAULT_NAME = 'Test Customer';
const DEFAULT_PHONE = ''; // Removed default phone number
const DEFAULT_GOVERNORATE = 'Duhok';
const DEFAULT_CITY = 'Duhok';
const DEFAULT_ADDRESS = 'Near Sarhaldan Park';
// ---

// --- TRANSLATIONS ---
const translations = {
  en: {
    cartTitle: 'Your Cart',
    emptyCart: 'Your cart is empty.',
    subtotal: 'Subtotal',
    checkout: 'Proceed to Order',
    checkoutTitle: 'Shipping & Confirmation',
    backToCart: 'Back to cart',
    shippingInfo: 'Shipping Information',
    fullName: 'Full Name',
    phoneLabel: 'Phone Number (Iraq)',
    phoneError: 'Please enter a valid 10 or 11 digit Iraqi number.',
    verifyVia: 'Verify via:',
    sms: 'SMS',
    whatsapp: 'WhatsApp',
    sending: 'Sending...',
    resendIn: 'Resend in {cooldown}s',
    resendCode: 'Resend Code',
    sendCode: 'Send Code',
    verificationCode: 'Verification Code',
    enter4DigitCode: 'Please enter the 4-digit verification code.',
    verifying: 'Verifying...',
    verify: 'Verify',
    governorate: 'Governorate',
    selectGovernorate: 'Select a governorate',
    city: 'City',
    selectCity: 'Select a city',
    address: 'Street / Closest Point',
    addressPlaceholder: 'e.g., Near Sarhaldan Park',
    infoLine1: 'We will contact you via WhatsApp to confirm item availability and prepare your order.',
    infoLine2: 'Delivery takes 1-4 days, depending on your address.',
    deliveryFee: 'Delivery Fee',
    total: 'Total',
    placingOrder: 'Placing Order...',
    placeOrder: 'Place Order',
    orderProblem: 'There was a problem placing your order. Please try again.',
    successTitle: 'Order Received!',
    successMessage: 'Thank you! We will contact you on WhatsApp to confirm your items.',
    successRedirect: 'You will be redirected shortly.',
    removeItem: 'Remove {itemTitle}',
    closeCart: 'Close cart',
    quotaError: 'Service busy. Please try verification via WhatsApp.',
  },
  ar: {
    cartTitle: 'سلّتك',
    emptyCart: 'سلّتك فارغة.',
    subtotal: 'المجموع الفرعي',
    checkout: 'متابعة للطلب',
    checkoutTitle: 'الشحن والتأكيد',
    backToCart: 'العودة للسلة',
    shippingInfo: 'معلومات الشحن',
    fullName: 'الاسم الكامل',
    phoneLabel: 'رقم الهاتف (العراق)',
    phoneError: 'الرجاء إدخال رقم عراقي صالح مكون من 10 أو 11 رقمًا.',
    verifyVia: 'التحقق عبر:',
    sms: 'رسالة نصية',
    whatsapp: 'واتساب',
    sending: 'جار الإرسال...',
    resendIn: 'إعادة الإرسال خلال {cooldown} ثانية',
    resendCode: 'إعادة إرسال الرمز',
    sendCode: 'إرسال الرمز',
    verificationCode: 'رمز التحقق',
    enter4DigitCode: 'الرجاء إدخال رمز التحقق المكون من 4 أرقام.',
    verifying: 'جار التحقق...',
    verify: 'تحقق',
    governorate: 'المحافظة',
    selectGovernorate: 'اختر محافظة',
    city: 'المدينة',
    selectCity: 'اختر مدينة',
    address: 'الشارع / أقرب نقطة دالة',
    addressPlaceholder: 'مثال: قرب حديقة سارهلدان',
    infoLine1: 'سنتواصل معك عبر الواتساب لتأكيد توفر المنتجات وتجهيز طلبك.',
    infoLine2: 'يستغرق التوصيل من يوم إلى 4 أيام، حسب عنوانك.',
    deliveryFee: 'رسوم التوصيل',
    total: 'المجموع الكلي',
    placingOrder: 'جار إرسال الطلب...',
    placeOrder: 'تأكيد الطلب',
    orderProblem: 'حدثت مشكلة أثناء تسجيل طلبك. الرجاء المحاولة مرة أخرى.',
    successTitle: 'تم استلام طلبك!',
    successMessage: 'شكراً لك! سنتواصل معك عبر الواتساب لتأكيد منتجاتك.',
    successRedirect: 'سيتم إعادتك قريباً.',
    removeItem: 'إزالة {itemTitle}',
    closeCart: 'إغلاق السلة',
    quotaError: 'الخدمة مشغولة. يرجى محاولة التحقق عبر الواتساب.',
  },
  ku: {
    cartTitle: 'سەلكا تە',
    emptyCart: 'سەلكا تە یا ڤالایە.',
    subtotal: 'کۆما گشتی یا بنەرەت',
    checkout: 'چوون بۆ داخازیێ',
    checkoutTitle: 'گهاندن و پشتراستکرن',
    backToCart: 'بزڤرە بۆ سەلکێ',
    shippingInfo: 'پێزانینێن گهاندنێ',
    fullName: 'ناڤێ سیانی',
    phoneLabel: 'ژمارا تەلەفونێ (عێراق)',
    phoneError: 'هیڤی دکەین ژمارەکا عیراقی یا دروست ژ 10 یان 11 خانان بنڤیسە.',
    verifyVia: 'پشتراستکرن ب رێکا:',
    sms: 'نامە',
    whatsapp: 'واتسئاپ',
    sending: 'د هـنارتنێ دایە...',
    resendIn: 'دوبارە هنارتن پشتی {cooldown} چرکە',
    resendCode: 'دوبارە هنارتنا کۆدی',
    sendCode: 'کۆدی بهنێرە',
    verificationCode: 'کۆدێ پشتراستکرنێ',
    enter4DigitCode: 'هیڤی دکەین کۆدێ پشتراستکرنێ ژ 4 ژماران بنڤیسە.',
    verifying: 'پشتراستکرن...',
    verify: 'پشتراستبکە',
    governorate: 'پارێزگەه',
    selectGovernorate: 'پارێزگەهەکێ هەلبژێرە',
    city: 'باژێر',
    selectCity: 'باژێرەکێ هەلبژێرە',
    address: 'جادە / نێزیکترین خال',
    addressPlaceholder: 'نموونە: نێزیک پارکا سەرهلدان',
    infoLine1: 'دێ ب رێکا واتسئاپێ پەیوەندیێ ب تە کەین بۆ پشتراستکرنا هەبوونا بەرهەمان و ئامادەکرنا داخازا تە.',
    infoLine2: 'گەهاندن د ناڤبەرا 1-4 رۆژان دایە، لدیڤ ناڤ و نیشانێن تە.',
    deliveryFee: 'کرێیا گەهاندنێ',
    total: 'کۆما گشتی',
    placingOrder: 'داخاز د هنارتنێ دایە...',
    placeOrder: 'داخازێ پشتراستبکە',
    orderProblem: 'کێشەیەک د تۆمارکرنا داخازا تە دا چێبوو. هیڤی دکەین دوبارە هەول بدە.',
    successTitle: 'داخازا تە هاتە وەرگرتن!',
    successMessage: 'سوپاس! دێ ب رێکا واتسئاپێ پەیوەندیێ ب تە کەین بۆ پشتراستکرنا بەرهەمان.',
    successRedirect: 'دێ نیزیك ڤەگەریہێ.',
    removeItem: 'ژێبرنا {itemTitle}',
    closeCart: 'سەلکێ بگرە',
    quotaError: 'خزمەتگوزاری مژوولە. هیڤیە ب رێکا واتسئاپێ تاقی بکە.',
  }
};

interface CartProps {
  isVisible: boolean;
  onClose: () => void;
  language: Language;
}

const Cart: React.FC<CartProps> = ({ isVisible, onClose, language }) => {
  const { cart, updateQuantity, removeFromCart, clearCart } = useCart();
  const { addToast } = useToast();
  const [view, setView] = useState<'cart' | 'checkout' | 'success'>('cart');
  
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'ku';

  // Checkout form state
  const [name, setName] = useState(DEFAULT_NAME);
  const [phone, setPhone] = useState(DEFAULT_PHONE);
  const [isPhoneValid, setIsPhoneValid] = useState(false);
  const [phoneError, setPhoneError] = useState('');
  const [verificationMethod, setVerificationMethod] = useState('whatsapp');
  const [isVerified, setIsVerified] = useState(false);
  const [governorate, setGovernorate] = useState(DEFAULT_GOVERNORATE);
  const [city, setCity] = useState(DEFAULT_CITY);
  const [addressLine, setAddressLine] = useState(DEFAULT_ADDRESS);
  const [cooldown, setCooldown] = useState(0);
  const [hasSentOnce, setHasSentOnce] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const cooldownTimerRef = useRef<number | null>(null);

  // Loading states
  const [isSendingCode, setIsSendingCode] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = subtotal + DELIVERY_FEE;

  useEffect(() => {
    if (cooldown > 0) {
      cooldownTimerRef.current = window.setTimeout(() => {
        setCooldown(prev => prev - 1);
      }, 1000);
    }
    return () => {
      if (cooldownTimerRef.current) {
        clearTimeout(cooldownTimerRef.current);
      }
    };
  }, [cooldown]);

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPhone = e.target.value;
    setPhone(newPhone);
    const phoneToTest = newPhone.replace(/\s/g, '');
    
    setIsVerified(false);
    setCooldown(0);
    setHasSentOnce(false);
    setVerificationCode('');
    if (cooldownTimerRef.current) {
      clearTimeout(cooldownTimerRef.current);
    }
    
    if (phoneToTest === '') {
        setIsPhoneValid(false);
        setPhoneError('');
        return;
    }

    const regex = /^0?7\d{9}$/;
    if (regex.test(phoneToTest)) {
        setIsPhoneValid(true);
        setPhoneError('');
    } else {
        setIsPhoneValid(false);
        setPhoneError(t.phoneError);
    }
  };
  
  useEffect(() => {
    if (phone && !isPhoneValid) {
        setPhoneError(t.phoneError);
    } else {
        setPhoneError('');
    }
  }, [language, phone, isPhoneValid, t.phoneError]);

  const handleGovernorateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setGovernorate(e.target.value);
    setCity('');
  };

  const handleSendCode = async () => {
    if (isPhoneValid && !isSendingCode && cooldown === 0) {
        setIsSendingCode(true);
        try {
            await sendVerificationCode(phone, verificationMethod as 'sms' | 'whatsapp');
            setHasSentOnce(true);
            setCooldown(60);
            addToast('Verification code sent!', 'success');
        } catch (error) {
            if (error instanceof Error) {
              // If we hit a specific error (like quota or generic failure), suggest trying the other method
              if (error.message.toLowerCase().includes('quota') || error.message.toLowerCase().includes('limit')) {
                 addToast(t.quotaError, 'error');
              } else {
                 addToast(error.message, 'error');
              }
            } else {
              addToast('Failed to send code.', 'error');
            }
        } finally {
            setIsSendingCode(false);
        }
    }
  };

  const handleVerifyCode = async () => {
      if (!verificationCode || verificationCode.length !== 4) {
          addToast(t.enter4DigitCode, 'error');
          return;
      }
      setIsVerifying(true);
      setPhoneError('');
      try {
        const success = await verifyCode(phone, verificationCode);
        if (success) {
            setIsVerified(true);
            addToast('Phone number verified!', 'success');
        }
      } catch (error) {
        if (error instanceof Error) {
            setPhoneError(error.message);
            addToast(error.message, 'error');
        } else {
            addToast('An unknown verification error occurred.', 'error');
        }
      } finally {
        setIsVerifying(false);
      }
  };

  const handleClose = () => {
    onClose();
  };

  useEffect(() => {
    if (!isVisible) {
      const timer = setTimeout(() => {
        setView('cart');
        setName(DEFAULT_NAME);
        setPhone(DEFAULT_PHONE);
        setIsPhoneValid(false);
        setPhoneError('');
        setGovernorate(DEFAULT_GOVERNORATE);
        setCity(DEFAULT_CITY);
        setAddressLine(DEFAULT_ADDRESS);
        setIsVerified(false);
        setCooldown(0);
        setHasSentOnce(false);
        setVerificationCode('');
        if (cooldownTimerRef.current) {
          clearTimeout(cooldownTimerRef.current);
        }
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  useEffect(() => {
    let timer: number;
    if (view === 'success') {
      timer = window.setTimeout(() => {
        handleClose();
      }, 3000);
    }
    return () => window.clearTimeout(timer);
  }, [view, handleClose]);

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isPlacingOrder) return;

    setIsPlacingOrder(true);

    const orderDetails: OrderDetails = {
      customer: { name, phone },
      shipping: { governorate, city, addressLine },
      items: cart.map(item => ({
        id: item.id,
        title: item.title[language],
        quantity: item.quantity,
        price: item.price,
      })),
      totals: {
        subtotal,
        deliveryFee: DELIVERY_FEE,
        total,
      }
    };

    try {
        await submitOrder(orderDetails);
        trackEvent('purchase', {
            transaction_id: `T-${Date.now()}-${cart.length}`,
            value: total,
            tax: 0,
            shipping: DELIVERY_FEE,
            currency: 'IQD',
            items: cart.map(item => ({
            item_id: item.id,
            item_name: item.title.en,
            price: item.price,
            quantity: item.quantity,
            })),
        });
        clearCart();
        setView('success');
    } catch (error) {
        if (error instanceof Error) addToast(error.message, 'error');
    } finally {
        setIsPlacingOrder(false);
    }
  };

  const isFormValid = name && isVerified && governorate && city && addressLine;

  const renderContent = () => {
    if (view === 'success') {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center text-gray-300 p-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-20 w-20 mb-4 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 className="text-xl font-semibold text-white">{t.successTitle}</h3>
            <p className="mt-2">{t.successMessage}</p>
            <p className="text-sm text-gray-500 mt-1">{t.successRedirect}</p>
        </div>
      );
    }

    if (view === 'checkout') {
      return (
        <>
          <header className="flex items-center justify-between p-4 border-b border-gray-800">
             <button onClick={() => setView('cart')} className="p-1 text-gray-400 hover:text-white transition-colors" aria-label={t.backToCart}>
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isRtl ? "M9 5l7 7-7 7" : "M15 19l-7-7 7-7"} />
                </svg>
             </button>
            <h2 id="cart-heading" className="text-lg font-semibold">
              {t.checkoutTitle}
            </h2>
            <div className="w-8"></div>
          </header>
          <form id="checkout-form" onSubmit={handlePlaceOrder} className="flex-grow overflow-y-auto p-4 space-y-6 text-left">
              <div>
                  <h3 className="text-md font-semibold text-gray-300 mb-3 border-b border-gray-800 pb-2">{t.shippingInfo}</h3>
                  <div className="space-y-4">
                      <div>
                          <label htmlFor="name" className="text-sm text-gray-400 block mb-1">{t.fullName}</label>
                          <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} required className="w-full bg-black/30 p-2 border border-gray-700 rounded-md focus:outline-none focus:ring-1 focus:ring-white/50" />
                      </div>
                      <div>
                          <label htmlFor="phone" className="text-sm text-gray-400 block mb-1">{t.phoneLabel}</label>
                          <div className="flex items-center" dir="ltr">
                            <input type="tel" id="phone" value={phone} onChange={handlePhoneChange} placeholder="e.g., 07501234567" required className={`w-full bg-black/30 p-2 border rounded-md focus:outline-none focus:ring-1 focus:ring-white/50 ${phone ? (isPhoneValid ? 'border-green-500' : 'border-red-500') : 'border-gray-700'}`} disabled={isVerified} />
                            {isVerified && <span className="ml-2 text-2xl" role="img" aria-label="Verified">✅</span>}
                          </div>
                          {phoneError && <p className="text-red-500 text-xs mt-1">{phoneError}</p>}
                      </div>

                      {!isVerified && isPhoneValid && (
                        <div className="bg-black/20 p-3 rounded-md border border-gray-700">
                          <div className="flex items-center space-x-4 text-sm">
                              <label className="text-gray-400">{t.verifyVia}</label>
                              <label className="flex items-center"><input type="radio" name="verification" value="sms" checked={verificationMethod === 'sms'} onChange={() => setVerificationMethod('sms')} className="mx-1" /> {t.sms}</label>
                              <label className="flex items-center"><input type="radio" name="verification" value="whatsapp" checked={verificationMethod === 'whatsapp'} onChange={() => setVerificationMethod('whatsapp')} className="mx-1" /> {t.whatsapp}</label>
                              <div className="ml-auto text-right" style={{minWidth: '110px'}}>
                                {isSendingCode ? (
                                    <span className="text-xs text-gray-400 px-3 py-1">{t.sending}</span>
                                ) : cooldown > 0 ? (
                                    <span className="text-xs text-gray-400 px-3 py-1">{t.resendIn.replace('{cooldown}', String(cooldown))}</span>
                                ) : (
                                    <button type="button" onClick={handleSendCode} disabled={!isPhoneValid} className="text-xs bg-white/10 px-3 py-1 rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-white/20 transition-colors">
                                        {hasSentOnce ? t.resendCode : t.sendCode}
                                    </button>
                                )}
                              </div>
                          </div>
                          {hasSentOnce && (
                            <div className="mt-4">
                                <label htmlFor="code" className="text-sm text-gray-400 block mb-1">{t.verificationCode}</label>
                                <div className="flex items-center space-x-2">
                                    <input 
                                        type="text" 
                                        id="code" 
                                        value={verificationCode} 
                                        onChange={e => setVerificationCode(e.target.value)} 
                                        maxLength={4}
                                        placeholder="1234"
                                        required 
                                        className="w-full bg-black/30 p-2 border border-gray-700 rounded-md focus:outline-none focus:ring-1 focus:ring-white/50" 
                                    />
                                    <button 
                                        type="button" 
                                        onClick={handleVerifyCode} 
                                        disabled={isVerifying || verificationCode.length !== 4}
                                        className="bg-white/10 px-4 py-2 rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-white/20 transition-colors whitespace-nowrap"
                                    >
                                        {isVerifying ? t.verifying : t.verify}
                                    </button>
                                </div>
                            </div>
                          )}
                        </div>
                      )}
                      
                      <div>
                          <label htmlFor="governorate" className="text-sm text-gray-400 block mb-1">{t.governorate}</label>
                          <select id="governorate" value={governorate} onChange={handleGovernorateChange} required className="w-full bg-black/30 p-2 border border-gray-700 rounded-md focus:outline-none focus:ring-1 focus:ring-white/50">
                              <option value="" disabled>{t.selectGovernorate}</option>
                              {GOVERNORATES.map(gov => <option key={gov} value={gov}>{gov}</option>)}
                          </select>
                      </div>
                      <div>
                          <label htmlFor="city" className="text-sm text-gray-400 block mb-1">{t.city}</label>
                          <select id="city" value={city} onChange={e => setCity(e.target.value)} required disabled={!governorate} className="w-full bg-black/30 p-2 border border-gray-700 rounded-md focus:outline-none focus:ring-1 focus:ring-white/50 disabled:opacity-50">
                               <option value="" disabled>{t.selectCity}</option>
                               {governorate && IRAQI_LOCATIONS[governorate as keyof typeof IRAQI_LOCATIONS].map(c => <option key={c} value={c}>{c}</option>)}
                          </select>
                      </div>
                      <div>
                          <label htmlFor="addressLine" className="text-sm text-gray-400 block mb-1">{t.address}</label>
                          <input
                            type="text"
                            id="addressLine"
                            value={addressLine}
                            onChange={e => setAddressLine(e.target.value)}
                            required
                            className="w-full bg-black/30 p-2 border border-gray-700 rounded-md focus:outline-none focus:ring-1 focus:ring-white/50"
                            placeholder={t.addressPlaceholder}
                          />
                      </div>
                  </div>
                  <div className="flex items-start space-x-2 text-xs text-amber-200 bg-amber-500/10 p-3 rounded-md mt-6 border border-amber-500/30">
                      <div>
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mt-0.5 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                      </div>
                      <div>
                          <p>{t.infoLine1}</p>
                          <p className="mt-1">{t.infoLine2}</p>
                      </div>
                  </div>
              </div>
          </form>
          <footer className="p-4 border-t border-gray-800 space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-400">{t.subtotal}</span>
                <span className="font-medium text-white">{subtotal.toLocaleString('en-US')} دينار</span>
              </div>
               <div className="flex justify-between items-center text-sm">
                <span className="text-gray-400">{t.deliveryFee}</span>
                <span className="font-medium text-white">{DELIVERY_FEE.toLocaleString('en-US')} دينار</span>
              </div>
              <div className="flex justify-between items-center text-lg pt-2 border-t border-gray-800 mt-2">
                <span className="text-white font-bold">{t.total}</span>
                <span className="font-bold text-white">{total.toLocaleString('en-US')} دينار</span>
              </div>
              <button
                type="submit"
                form="checkout-form"
                disabled={!isFormValid || isPlacingOrder}
                className="w-full bg-white text-black font-bold py-3 rounded-lg hover:bg-gray-300 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isPlacingOrder ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>{t.placingOrder}</span>
                  </>
                ) : (
                  t.placeOrder
                )}
              </button>
            </footer>
        </>
      );
    }
    
    return (
        <>
            <header className="flex items-center justify-between p-4 border-b border-gray-800">
              <h2 id="cart-heading" className="text-lg font-semibold">
                {t.cartTitle}
              </h2>
              <button onClick={handleClose} className="p-1 text-gray-400 hover:text-white transition-colors" aria-label={t.closeCart}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </header>
            <div className="flex-grow overflow-y-auto p-4">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-gray-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                <p>{t.emptyCart}</p>
              </div>
            ) : (
              <ul className="space-y-4">
                {cart.map(item => (
                  <li key={item.id} className="flex items-center space-x-4">
                    <img src={item.image} alt={item.title[language]} className="w-16 h-20 object-cover rounded-md border border-gray-800" />
                    <div className="flex-grow">
                      <p className="text-sm font-medium text-gray-200">{item.title[language]}</p>
                      <p className="text-xs text-gray-400">{item.price.toLocaleString('en-US')} دينار</p>
                      <div className="flex items-center mt-2">
                        <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="px-2 py-0.5 border border-gray-700 rounded-l-md hover:bg-gray-800">-</button>
                        <span className="px-3 py-0.5 border-t border-b border-gray-700">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="px-2 py-0.5 border border-gray-700 rounded-r-md hover:bg-gray-800">+</button>
                      </div>
                    </div>
                    <button onClick={() => removeFromCart(item.id)} className="text-gray-500 hover:text-red-500 transition-colors" aria-label={t.removeItem.replace('{itemTitle}', item.title[language])}>
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </li>
                ))}
              </ul>
            )}
            </div>
            
            {cart.length > 0 && (
            <footer className="p-4 border-t border-gray-800">
              <div className="flex justify-between items-center mb-4">
                <span className="text-gray-400">{t.subtotal}</span>
                <span className="font-semibold text-white">{subtotal.toLocaleString('en-US')} دينار</span>
              </div>
              <button
                onClick={() => {
                  setView('checkout');
                  trackEvent('begin_checkout', {
                      currency: 'IQD',
                      value: total,
                      items: cart.map(item => ({
                          item_id: item.id,
                          item_name: item.title.en,
                          price: item.price,
                          quantity: item.quantity,
                      })),
                  });
                }}
                className="w-full bg-white text-black font-bold py-3 rounded-lg hover:bg-gray-300 transition-colors"
              >
                {t.checkout}
              </button>
            </footer>
          )}
        </>
    );
  };

  return (
    <>
      <div
        className={`fixed inset-0 bg-black/60 z-40 transition-opacity duration-300 ${
          isVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={handleClose}
      ></div>
      <aside
        className={`fixed top-0 right-0 h-full w-full max-w-sm bg-black/80 backdrop-blur-lg border-l border-gray-800 z-50 transform transition-transform duration-300 ease-in-out ${
          isVisible ? 'translate-x-0' : 'translate-x-full'
        }`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="cart-heading"
        dir={isRtl ? 'rtl' : 'ltr'}
      >
        <div className="flex flex-col h-full text-white">
          {renderContent()}
        </div>
      </aside>
    </>
  );
};

export default Cart;