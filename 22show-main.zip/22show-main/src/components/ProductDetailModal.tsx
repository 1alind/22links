
import React, { useRef, useEffect } from 'react';
import type { Product, Language } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onProductAdded: (product: Product, imageElement: HTMLImageElement) => void;
  addToCartText: string;
  language: Language;
}

const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, onClose, onProductAdded, addToCartText, language }) => {
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  if (!product) return null;

  const handleAddToCart = () => {
    if (imgRef.current) {
      onProductAdded(product, imgRef.current);
      onClose(); // Close modal after adding to cart
    }
  };

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="product-title"
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm modal-backdrop-enter"
        onClick={onClose}
      ></div>

      {/* Modal Content */}
      <div className="relative z-10 w-full max-w-4xl max-h-[90vh] bg-black/50 border border-gray-800 rounded-lg shadow-xl modal-content-enter overflow-y-auto">
        <div className="grid md:grid-cols-2 gap-6 md:gap-8 p-6 md:p-8">
          {/* Image Column */}
          <div className="aspect-square md:aspect-[4/5] w-full bg-black/20 rounded-lg overflow-hidden">
            <img
              ref={imgRef}
              src={product.image}
              alt={product.title[language]}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Details Column */}
          <div className="flex flex-col text-white">
            <h2 id="product-title" className="text-2xl md:text-3xl font-bold">
              {product.title[language]}
            </h2>
            <p className="text-xl md:text-2xl text-amber-400 font-semibold mt-2">
              {product.price.toLocaleString('en-US')} دينار
            </p>
            <div className="mt-4 pr-4 text-gray-300 text-sm md:text-base space-y-3 flex-grow overflow-y-auto max-h-64 md:max-h-none">
                {product.description[language].split('\n').map((paragraph, index) => (
                    <p key={index}>{paragraph}</p>
                ))}
            </div>
            <button
              onClick={handleAddToCart}
              className="w-full mt-6 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold py-3 px-6 rounded-lg transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-amber-500/30 focus:outline-none focus:ring-2 focus:ring-amber-300"
            >
              {addToCartText}
            </button>
          </div>
        </div>
        
        {/* Close Button */}
        <button
            onClick={onClose}
            className="absolute top-3 right-3 p-2 text-gray-400 bg-black/30 rounded-full hover:text-white hover:bg-white/10 transition-colors"
            aria-label="Close product details"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
        </button>
      </div>
    </div>
  );
};

export default ProductDetailModal;