
import React from 'react';
import Icon from './Icon';
import { trackEvent } from '../analytics';

interface LinkButtonProps {
  title: string;
  url: string;
  icon: string;
  isAnimating: boolean;
  onAnimationEnd: () => void;
  download?: string;
}

const LinkButton: React.FC<LinkButtonProps> = ({ title, url, icon, isAnimating, onAnimationEnd, download }) => {
  const handleClick = () => {
    // 1. Standard GA4 recommended event (good for advanced analysis)
    trackEvent('select_content', {
      content_type: 'link',
      item_id: title,
    });

    // 2. Specific event for easy dashboard reading (e.g., "click_whatsapp")
    // This creates a separate row in your Events table for each link.
    const specificEventName = `click_${title.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`;
    trackEvent(specificEventName, {
        destination: url
    });
  };
  
  return (
    <a
      href={url}
      target={download ? undefined : "_blank"}
      download={download}
      rel="noopener noreferrer"
      onClick={handleClick}
      className="relative group flex items-center justify-center w-full bg-white/5 backdrop-blur-sm border border-white/10 text-white text-center py-3 px-4 md:p-4 rounded-lg shadow-lg transition-all duration-300 ease-in-out hover:bg-white/10 hover:border-amber-400 hover:scale-105 hover:shadow-xl hover:shadow-amber-500/10 focus:outline-none focus:ring-2 focus:ring-amber-400/50 overflow-hidden"
    >
      {/* Shimmer Animation */}
      <span
        className={`absolute inset-0 -translate-x-full transform -skew-x-12 bg-gradient-to-r from-transparent via-white/10 to-transparent ${isAnimating ? 'animate-shimmer' : ''}`}
        onAnimationEnd={isAnimating ? onAnimationEnd : undefined}
      ></span>
      
      <div className="absolute z-10 left-4 top-1/2 -translate-y-1/2">
        <Icon name={icon} />
      </div>
      <span className="relative z-10 font-semibold text-sm md:text-lg">{title}</span>
    </a>
  );
};

export default LinkButton;