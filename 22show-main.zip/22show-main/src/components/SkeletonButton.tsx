import React from 'react';

const SkeletonButton: React.FC = () => {
  return (
    <div className="relative group flex items-center justify-center w-full bg-white/5 backdrop-blur-sm border border-white/10 text-white text-center py-3 px-4 md:p-4 rounded-lg shadow-lg animate-pulse">
      <div className="absolute z-10 left-4 top-1/2 -translate-y-1/2">
        <div className="w-6 h-6 md:w-7 md:h-7 bg-gray-700 rounded-full"></div>
      </div>
      <div className="h-5 md:h-6 bg-gray-700 rounded w-1/3"></div>
    </div>
  );
};

export default SkeletonButton;
