import React from 'react';
import Background from './Background';

const NotFound: React.FC = () => {
  return (
    <div className="relative min-h-screen w-full bg-black text-white flex flex-col items-center justify-center p-4 text-center overflow-hidden">
      <Background />
      <div className="relative z-10 flex flex-col items-center animate-fade-in">
        <div className="mb-6 text-amber-500">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 opacity-80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <h1 className="text-6xl md:text-8xl font-bold tracking-tighter mb-2 bg-clip-text text-transparent bg-gradient-to-b from-white to-gray-600">
            404
        </h1>
        <h2 className="text-xl md:text-2xl font-semibold text-white mb-4">Page Not Found</h2>
        <p className="text-gray-400 max-w-md mb-8 leading-relaxed">
          The page you are looking for doesn't exist or has been moved.
        </p>
        <a
          href="/"
          className="bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold py-3 px-8 rounded-lg shadow-lg shadow-amber-500/20 hover:scale-105 hover:shadow-amber-500/40 transition-all duration-300"
        >
          Go Back Home
        </a>
      </div>
    </div>
  );
};

export default NotFound;