
import React from 'react';

interface IconProps {
  name: string;
}

const Icon: React.FC<IconProps> = ({ name }) => {
  switch (name) {
    case 'whatsapp':
      return (
        <img
          src="https://1alind.sirv.com/Images/whatsapp_logo.png"
          alt="WhatsApp Logo"
          className="w-6 h-6 md:w-7 md:h-7"
        />
      );
    case 'instagram':
      return (
        <img
          src="https://1alind.sirv.com/Images/instagram.png"
          alt="Instagram Logo"
          className="w-6 h-6 md:w-7 md:h-7"
        />
      );
    case 'tiktok':
        return (
          <img
            src="https://1alind.sirv.com/Images/tiktok_logo.png"
            alt="TikTok Logo"
            className="w-6 h-6 md:w-7 md:h-7"
          />
        );
    case 'snapchat':
      return (
        <img
          src="https://1alind.sirv.com/Images/snapchat_logo.png"
          alt="Snapchat Logo"
          className="w-6 h-6 md:w-7 md:h-7"
        />
      );
    case 'apple-maps':
      return (
        <img
          src="https://1alind.sirv.com/Images/AppleMaps_logo.png"
          alt="Apple Maps Logo"
          className="w-6 h-6 md:w-7 md:h-7 rounded-md"
        />
      );
    case 'google-maps':
      return (
        <img
          src="https://1alind.sirv.com/Images/GoogleMaps_logo.png"
          alt="Google Maps Logo"
          className="w-6 h-6 md:w-7 md:h-7"
        />
      );
    case 'contact':
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-6 h-6 md:w-7 md:h-7"
        >
          <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
          <circle cx="8.5" cy="7" r="4"></circle>
          <line x1="20" y1="8" x2="20" y2="14"></line>
          <line x1="23" y1="11" x2="17" y2="11"></line>
        </svg>
      );
    case 'shop':
      return (
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
          className="w-6 h-6 md:w-7 md:h-7"
        >
          <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
          <line x1="3" y1="6" x2="21" y2="6"></line>
          <path d="M16 10a4 4 0 0 1-8 0"></path>
        </svg>
      );
    case 'globe':
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
          className="w-5 h-5"
        >
          <circle cx="12" cy="12" r="10"></circle>
          <line x1="2" y1="12" x2="22" y2="12"></line>
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1 4-10z"></path>
        </svg>
      );
    case 'map-pin':
      return (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
          className="w-5 h-5"
        >
          <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
          <circle cx="12" cy="10" r="3"></circle>
        </svg>
      );
    default:
      return null;
  }
};

export default Icon;