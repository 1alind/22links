
export type Language = 'en' | 'ar' | 'ku';

export const languageOptions: Record<Language, { name: string; flag: string; }> = {
    en: { name: 'English', flag: 'https://flagcdn.com/us.svg' },
    ar: { name: 'العربية', flag: 'https://flagcdn.com/iq.svg' },
    ku: { name: 'Kurdî (Badînî)', flag: 'https://upload.wikimedia.org/wikipedia/commons/3/35/Flag_of_Kurdistan.svg' }
};

export interface Link {
  id: number;
  title: string;
  url: string;
  icon: string;
  download?: string;
}

export interface Product {
  id: number;
  title: Record<Language, string>;
  price: number;
  image: string;
  description: Record<Language, string>;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface OrderDetails {
  customer: {
    name: string;
    phone: string;
  };
  shipping: {
    governorate: string;
    city: string;
    addressLine: string;
  };
  items: Array<{
    id: number;
    title: string;
    quantity: number;
    price: number;
  }>;
  totals: {
    subtotal: number;
    deliveryFee: number;
    total: number;
  };
}