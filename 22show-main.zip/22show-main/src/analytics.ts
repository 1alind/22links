/**
 * Sends an event to Google Analytics.
 * @param eventName The name of the event (e.g., 'add_to_cart').
 * @param eventParams An object of parameters for the event.
 */
export const trackEvent = (
  eventName: string,
  eventParams?: Record<string, any>
): void => {
  if (typeof window.gtag === 'function') {
    window.gtag('event', eventName, eventParams);
  } else {
    // This can happen if GA is blocked or hasn't loaded yet.
    // We can console.log for development purposes.
    console.log(`GA Event (gtag not found): ${eventName}`, eventParams || '');
  }
};
