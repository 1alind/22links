
import React, { useState, useCallback, forwardRef, useRef, useEffect } from 'react';
import LinkButton from './components/LinkButton';
import Icon from './components/Icon';
import type { Link, Product, Language } from './types';
import Background from './components/Background';
import Shop from './components/ComingSoon';
import Cart from './components/Cart';
import { CartProvider, useCart } from './hooks/useCart';
import { ToastProvider, useToast } from './hooks/useToast';
import { SHOP_ENABLED, SHOW_SHOP_BUTTON, GEOLOCATION_ENABLED, ALLOWED_COUNTRY_CODE } from '../config';
import { trackEvent } from './analytics';
import SkeletonButton from './components/SkeletonButton';
import ErrorBoundary from './components/ErrorBoundary';
import NotFound from './components/NotFound';

// --- Data Constants ---
// Note: We use \r\n for vCard standard compliance in the generation logic below.
const BASE_VCARD_CONTENT = `BEGIN:VCARD
VERSION:3.0
FN:22 show 👕
N:;22 show 👕;;;
ORG:22 Show
TEL;TYPE=CELL:+9647501859616
URL;type=Instagram:https://instagram.com/22show_
URL;type=TikTok:https://www.tiktok.com/@22show_
URL;type=Snapchat:https://t.snapchat.com/RInsrLAk
URL;type=Google Maps:https://maps.app.goo.gl/G7xczmrF6BWAdxoCA
URL;type=Apple Maps:https://maps.apple.com/place?address=Kurdistan%20Salh,%20Duhok,%20Iraq&coordinate=36.850062,43.038856&name=22%20Show&place-id=I81229B1DA5447AFB&map=explore
URL;type=Website:https://22show.vercel.app/
NOTE:بوفروتنا جل و بەرگێن گەنجان
{PHOTO_SECTION}
END:VCARD`;

const LINKS: Link[] = [
  { id: 1, title: 'WhatsApp', url: 'https://wa.me/9647501859616', icon: 'whatsapp' },
  { id: 2, title: 'Instagram', url: 'https://instagram.com/22show_', icon: 'instagram' },
  { id: 3, title: 'TikTok', url: 'https://www.tiktok.com/@22show_', icon: 'tiktok' },
  { id: 4, title: 'Snapchat', url: 'https://t.snapchat.com/RInsrLAk', icon: 'snapchat' },
  { id: 7, title: 'Save Contact', url: '', icon: 'contact', download: '22show.vcf' }, // URL populated dynamically
  { id: 5, title: 'Apple Maps', url: 'https://maps.apple/p/zWP3Cc9SNRqCBz', icon: 'apple-maps' },
  { id: 6, title: 'Google Maps', url: 'https://maps.app.goo.gl/G7xczmrF6BWAdxoCA', icon: 'google-maps' },
];

const EMOJI_LIST = ['👕', '👖', '👟', '🥾', '🩳', '🧦', '🧢', '🕶️', '⌚️', '🚕'];

const TOAST_MESSAGES: Record<Language, string> = {
  en: '{product} added to cart',
  ar: 'تم إضافة {product} إلى السلة',
  ku: '{product} ل سەلکێ هاتە زێدەکرن'
};

// --- Custom Hook for animations ---
const useCyclicalAnimations = (emojiList: string[], linkCount: number) => {
  const [emojiIndex, setEmojiIndex] = useState(0);
  const [animatedLinkIndex, setAnimatedLinkIndex] = useState(0);

  const handleEmojiAnimationIteration = useCallback(() => {
    setEmojiIndex(current => current + 2);
  }, []);

  const handleShimmerAnimationEnd = useCallback(() => {
    setAnimatedLinkIndex(current => (current + 1) % linkCount);
  }, [linkCount]);

  const currentEmoji1 = emojiList[emojiIndex % emojiList.length];
  const currentEmoji2 = emojiList[(emojiIndex + 1) % emojiList.length];

  return {
    animatedLinkIndex,
    currentEmoji1,
    currentEmoji2,
    handleEmojiAnimationIteration,
    handleShimmerAnimationEnd,
  };
};

const CartIcon = forwardRef<HTMLButtonElement, { onClick: () => void, isGlowing: boolean }>(({ onClick, isGlowing }, ref) => {
    const { cart } = useCart();
    const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

    if (itemCount === 0) return null;

    return (
        <button
            ref={ref}
            onClick={onClick}
            className={`fixed top-4 right-4 z-50 bg-black/50 backdrop-blur-md p-3 rounded-full text-white border border-gray-700 hover:border-amber-400 transition-colors ${isGlowing ? 'animate-glow' : ''}`}
            aria-label={`Shopping cart with ${itemCount} items`}
        >
            <Icon name="shop" />
            <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                {itemCount}
            </span>
        </button>
    );
});


// --- App Content Component ---
const AppContent: React.FC = () => {
  // Determine if shop should be shown based on config or URL override
  const searchParams = new URLSearchParams(window.location.search);
  const isBypassActive = searchParams.has('1alind');
  const shouldShowShopButton = SHOW_SHOP_BUTTON || isBypassActive;

  const {
    animatedLinkIndex,
    currentEmoji1,
    currentEmoji2,
    handleEmojiAnimationIteration,
    handleShimmerAnimationEnd,
  } = useCyclicalAnimations(EMOJI_LIST, LINKS.length);
  
  const { cart, addToCart } = useCart();
  const { addToast } = useToast();
  const [isShopVisible, setIsShopVisible] = useState(false);
  const [isCartVisible, setIsCartVisible] = useState(false);
  const [isCartGlowing, setIsCartGlowing] = useState(false);
  const [language, setLanguage] = useState<Language>('en');
  const cartIconRef = useRef<HTMLButtonElement>(null);
  const [flyingImage, setFlyingImage] = useState<{ src: string, rect: DOMRect } | null>(null);
  const flyerRef = useRef<HTMLImageElement>(null);
  const [animatingProductId, setAnimatingProductId] = useState<number | null>(null);
  const [pendingAnimation, setPendingAnimation] = useState<{ product: Product, rect: DOMRect } | null>(null);
  const [vcardUrl, setVcardUrl] = useState<string>('#');
  
  // Geolocation state
  const [isShopAccessible, setIsShopAccessible] = useState(!GEOLOCATION_ENABLED || isBypassActive);
  const [isCheckingLocation, setIsCheckingLocation] = useState(shouldShowShopButton && SHOP_ENABLED && GEOLOCATION_ENABLED && !isBypassActive);


  // Track initial page view
  useEffect(() => {
    trackEvent('page_view', {
        page_title: document.title,
        page_location: window.location.href,
    });
  }, []);

  // Generate vCard with embedded photo
  useEffect(() => {
    let objectUrl: string | null = null;
    
    const generateVCard = async () => {
      try {
        const imgUrl = 'https://1alind.sirv.com/Images/22show_logo2.jpeg';
        // Add cache buster to attempt to bypass potential CORS cache issues
        const response = await fetch(imgUrl + '?t=' + new Date().getTime());
        const blob = await response.blob();
        
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result as string;
          const base64data = result.split(',')[1];
          
          // Fold lines at 72 chars, indented by one space for continuation.
          // This is critical for vCard 3.0 compliance so the photo is parsed correctly.
          // Using \r\n for standard vCard line endings.
          const chunks = base64data.match(/.{1,72}/g);
          const foldedBase64 = chunks ? chunks.join('\r\n ') : base64data;
          
          const photoBlock = `PHOTO;TYPE=JPEG;ENCODING=b:\r\n ${foldedBase64}`;
          
          // Replace \n with \r\n for the entire content and inject photo
          let vcardContent = BASE_VCARD_CONTENT.replace(/\n/g, '\r\n');
          vcardContent = vcardContent.replace('{PHOTO_SECTION}', photoBlock);
          
          const vcardBlob = new Blob([vcardContent], { type: 'text/vcard;name=22show.vcf' });
          objectUrl = URL.createObjectURL(vcardBlob);
          setVcardUrl(objectUrl);
        };
        reader.readAsDataURL(blob);
      } catch (error) {
        console.error("Error generating vCard photo:", error);
        // Fallback to remote URI if fetching fails
        const photoBlock = `PHOTO;TYPE=JPEG;VALUE=URI:https://1alind.sirv.com/Images/22show_logo2.jpeg`;
        const vcardContent = BASE_VCARD_CONTENT.replace(/\n/g, '\r\n').replace('{PHOTO_SECTION}', photoBlock);
        const dataUrl = `data:text/vcard;charset=utf-8,${encodeURIComponent(vcardContent)}`;
        setVcardUrl(dataUrl);
      }
    };

    generateVCard();

    // Cleanup Blob URL on unmount
    return () => {
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, []);
  
  // Geolocation check effect
  useEffect(() => {
    if (isBypassActive) {
        setIsShopAccessible(true);
        setIsCheckingLocation(false);
        return;
    }

    if (!shouldShowShopButton || !SHOP_ENABLED || !GEOLOCATION_ENABLED) {
      return;
    }

    const checkUserLocation = async () => {
      try {
        const response = await fetch('/api/geolocate');
        if (!response.ok) {
          throw new Error('Geolocation check failed');
        }
        const data = await response.json();
        setIsShopAccessible(data.country === ALLOWED_COUNTRY_CODE);
      } catch (error) {
        console.error("Failed to fetch user location:", error);
        setIsShopAccessible(false); 
      } finally {
        setIsCheckingLocation(false);
      }
    };

    checkUserLocation();
  }, [shouldShowShopButton, isBypassActive]);

  const handleAddToCartWithAnimation = useCallback((product: Product, imageElement: HTMLImageElement) => {
    addToCart(product);
    const message = TOAST_MESSAGES[language].replace('{product}', product.title[language]);
    addToast(message, 'success');
    trackEvent('add_to_cart', {
      currency: 'IQD',
      value: product.price,
      items: [{
          item_id: product.id,
          item_name: product.title.en,
          price: product.price,
          quantity: 1,
      }]
    });
    const startRect = imageElement.getBoundingClientRect();
    setPendingAnimation({ product, rect: startRect });
  }, [addToCart, addToast, language]);
  
  // Effect to START the animation once the cart icon is rendered
  useEffect(() => {
    if (pendingAnimation && cartIconRef.current) {
        setFlyingImage({ src: pendingAnimation.product.image, rect: pendingAnimation.rect });
        setAnimatingProductId(pendingAnimation.product.id);
        setPendingAnimation(null);
    }
  }, [pendingAnimation, cart]);

  // Effect for the "fly to cart" animation
  useEffect(() => {
    if (!flyingImage || !flyerRef.current || !cartIconRef.current) return;

    const flyer = flyerRef.current;
    const endRect = cartIconRef.current.getBoundingClientRect();

    requestAnimationFrame(() => {
        flyer.style.left = `${endRect.left + endRect.width / 2 - flyingImage.rect.width / 4}px`;
        flyer.style.top = `${endRect.top + endRect.height / 2 - flyingImage.rect.height / 4}px`;
        flyer.style.width = '20px';
        flyer.style.height = '20px';
        flyer.style.opacity = '0';
        flyer.style.transform = 'scale(0.2) rotate(180deg)';
    });
    
    const animationTimer = setTimeout(() => {
      setFlyingImage(null);
      setIsCartGlowing(true);
      setAnimatingProductId(null);
    }, 700);

    return () => clearTimeout(animationTimer);
  }, [flyingImage]);

  // Effect for the cart glowing animation
  useEffect(() => {
    if (isCartGlowing) {
      const glowTimer = setTimeout(() => {
        setIsCartGlowing(false);
      }, 1000);
      return () => clearTimeout(glowTimer);
    }
  }, [isCartGlowing]);

  return (
    <div className={`relative min-h-screen w-full bg-transparent text-white flex flex-col items-center px-4 py-8 ${isShopVisible ? 'justify-start overflow-y-auto' : 'justify-center overflow-hidden'}`}>
      <Background />
      {flyingImage && (
          <img
              ref={flyerRef}
              src={flyingImage.src}
              className="fly-to-cart"
              style={{
                  top: `${flyingImage.rect.top}px`,
                  left: `${flyingImage.rect.left}px`,
                  width: `${flyingImage.rect.width}px`,
                  height: `${flyingImage.rect.height}px`,
              }}
              alt=""
          />
      )}
      {isShopVisible && <CartIcon ref={cartIconRef} onClick={() => setIsCartVisible(true)} isGlowing={isCartGlowing} />}
      <Cart isVisible={isCartVisible} onClose={() => setIsCartVisible(false)} language={language} />
      
      {isShopVisible ? (
        <Shop onClose={() => setIsShopVisible(false)} onProductAdded={handleAddToCartWithAnimation} animatingProductId={animatingProductId} language={language} onLanguageChange={setLanguage} />
      ) : (
        <main className="relative z-20 flex flex-col items-center w-full max-w-md md:max-w-lg mx-auto text-center animate-fade-in">
          <header className="mb-10 md:mb-12 flex flex-col items-center">
            <img
              src="https://1alind.sirv.com/Images/22show_logo.jpeg"
              alt="22 Show - Men's Clothing Store in Duhok"
              className="w-20 h-20 md:w-24 md:h-24 rounded-full shadow-lg mb-4 object-cover border-2 border-white/10 transition-colors duration-300 hover:border-amber-400"
            />
            <h1 className="relative text-2xl md:text-4xl font-bold tracking-tight text-white flex items-center justify-center">
              <span>22 Show</span>
              <div className="absolute left-full ml-3 top-1/2 -translate-y-1/2 flex items-center">
                <div className="emoji-slider">
                  <span
                    className="emoji"
                    aria-hidden="true"
                    onAnimationIteration={handleEmojiAnimationIteration}
                  >
                    {currentEmoji1}
                  </span>
                  <span className="emoji emoji-2" aria-hidden="true">{currentEmoji2}</span>
                </div>
              </div>
            </h1>
            <p className="mt-2 text-sm md:text-base text-gray-400">
              بو فروتنا جل و بەرگێن گەنجان
            </p>
            <p className="mt-1 text-sm md:text-base text-gray-400">
              دهوك - تاخێ سەرهلدان، نێزیک پارکا سەرهلدان
            </p>
          </header>

          <section className="w-4/5 md:w-full space-y-4">
            {isCheckingLocation ? (
              <>
                {[...Array(LINKS.length + (shouldShowShopButton ? 1 : 0))].map((_, index) => (
                  <SkeletonButton key={`skel-${index}`} />
                ))}
              </>
            ) : (
              <>
                {LINKS.map((link, index) => (
                  <LinkButton
                    key={link.id}
                    title={link.title}
                    url={link.id === 7 ? vcardUrl : link.url}
                    icon={link.icon}
                    isAnimating={animatedLinkIndex === index}
                    onAnimationEnd={handleShimmerAnimationEnd}
                    download={link.download}
                  />
                ))}
                {shouldShowShopButton && (
                  SHOP_ENABLED ? (
                    isShopAccessible ? (
                      <div
                        role="button"
                        tabIndex={0}
                        onClick={() => {
                          setIsShopVisible(true);
                          trackEvent('view_item_list', {
                            item_list_id: 'shop_main',
                            item_list_name: 'Online Shop',
                          });
                          trackEvent('click_online_shop', {});
                        }}
                        onKeyDown={(e) => { 
                          if (e.key === 'Enter') {
                            setIsShopVisible(true);
                            trackEvent('view_item_list', {
                              item_list_id: 'shop_main',
                              item_list_name: 'Online Shop',
                            });
                            trackEvent('click_online_shop', {});
                          }
                        }}
                        className="relative group flex items-center justify-center w-full bg-gradient-to-r from-amber-500 to-amber-600 text-black text-center py-3 px-4 md:p-4 rounded-lg shadow-lg transition-all duration-300 ease-in-out hover:scale-105 hover:shadow-amber-400/50 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-amber-300 cursor-pointer"
                      >
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-black/80">
                          <Icon name="shop" />
                        </div>
                        <span className="font-bold text-sm md:text-lg">
                          Online Shop {isBypassActive ? '(Admin Bypass)' : '(BETA)'}
                        </span>
                      </div>
                    ) : (
                      <div
                        className="relative flex items-center justify-center w-full bg-white/5 backdrop-blur-sm border border-white/10 text-gray-500 text-center py-3 px-4 md:p-4 rounded-lg shadow-inner cursor-not-allowed"
                      >
                        <div className="absolute left-4 top-1/2 -translate-y-1/2">
                          <Icon name="shop" />
                        </div>
                        <span className="font-semibold text-sm md:text-lg">
                          Online Shop <span className="text-xs font-normal">(Not available in your region)</span>
                        </span>
                      </div>
                    )
                  ) : (
                     <div
                      className="relative flex items-center justify-center w-full bg-white/5 backdrop-blur-sm border border-white/10 text-gray-500 text-center py-3 px-4 md:p-4 rounded-lg shadow-inner cursor-not-allowed"
                    >
                      <div className="absolute left-4 top-1/2 -translate-y-1/2">
                        <Icon name="shop" />
                      </div>
                      <span className="font-semibold text-sm md:text-lg">
                        Online Shop <span className="text-xs font-normal">(Under Maintenance)</span>
                      </span>
                    </div>
                  )
                )}

                {/* Map Preview Widget */}
                <div className="w-full pt-4 animate-fade-in">
                    <div className="w-full aspect-video rounded-lg overflow-hidden border border-white/10 shadow-lg relative bg-gray-900 group">
                      {/* Crop the top info card from the iframe by shifting it up and increasing height */}
                      <iframe 
                          width="100%" 
                          height="100%"
                          style={{ border: 0, height: 'calc(100% + 300px)', marginTop: '-150px' }} 
                          loading="lazy" 
                          allowFullScreen 
                          src="https://maps.google.com/maps?q=36.850062,43.038856+(22%20Show)&t=&z=15&ie=UTF8&output=embed"
                          title="Location Map Preview"
                          className="opacity-80 group-hover:opacity-100 transition-opacity duration-300"
                      ></iframe>
                    </div>
                    <p className="text-xs text-gray-500 mt-2 text-center flex items-center justify-center gap-1">
                      <span className="text-amber-500"><Icon name="map-pin" /></span>
                      Sarhaldan Quarter, near Sarhaldan Park
                    </p>
                </div>
              </>
            )}
          </section>

          <footer className="mt-8 md:mt-12">
            <p className="mt-6 text-sm text-gray-500">
              &copy; {new Date().getFullYear()} 22 Show. All Rights Reserved.
            </p>
          </footer>
        </main>
      )}
    </div>
  );
};


// --- Main App Component Wrapper ---
const App: React.FC = () => {
  const [is404, setIs404] = useState(false);

  useEffect(() => {
    // Simple client-side check for 404 conditions
    // If the path is anything other than root or index.html, assume 404 since this is an SPA without a router
    if (window.location.pathname !== '/' && window.location.pathname !== '/index.html') {
      setIs404(true);
    }
  }, []);

  if (is404) {
    return <NotFound />;
  }

  return (
    <ErrorBoundary>
      <CartProvider>
        <ToastProvider>
          <AppContent />
        </ToastProvider>
      </CartProvider>
    </ErrorBoundary>
  )
}

export default App;
