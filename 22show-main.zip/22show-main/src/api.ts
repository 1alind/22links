import axios from 'axios';
import type { OrderDetails } from './types';

// --- API CALLS ---

/**
 * Calls the backend to generate an OTP, store it, and send it to the user.
 * @returns A promise that resolves to true on success, throws an error on failure.
 */
export const sendVerificationCode = async (phone: string, method: 'sms' | 'whatsapp'): Promise<boolean> => {
  try {
    await axios.post('/api/send-verification', { phone, method });
    return true;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error('Error sending verification code:', error.response?.data?.error);
      throw new Error(error.response?.data?.error || 'Failed to send code. Please try again later.');
    } else {
      console.error('An unexpected error occurred:', error);
      throw new Error('An unexpected error occurred while sending the code.');
    }
  }
};

/**
 * Verifies the user-provided OTP against the one stored in Redis via our backend.
 * @returns A promise that resolves to true on success, throws an error on failure.
 */
export const verifyCode = async (phone: string, code: string): Promise<boolean> => {
  try {
    const response = await axios.post('/api/verify-otp', { phone, code: code.trim() });
    return response.data.success === true;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error('Error verifying OTP:', error.response?.data?.error);
      throw new Error(error.response?.data?.error || 'Verification failed. Please try again.');
    } else {
      console.error('An unexpected error occurred during verification:', error);
      throw new Error('An unexpected error occurred during verification.');
    }
  }
};

/**
 * Submits a new order by sending it to our secure backend endpoint.
 * @returns A promise that resolves to true on success, throws an error on failure.
 */
export const submitOrder = async (orderDetails: OrderDetails): Promise<boolean> => {
    try {
        await axios.post('/api/submit-order', { orderDetails });
        console.log('Order submitted successfully via backend.');
        return true;
    } catch (error) {
        if (axios.isAxiosError(error)) {
            console.error('Error submitting order:', error.response?.data?.error);
             throw new Error(error.response?.data?.error || 'There was an error submitting your order. Please try again.');
        } else {
            console.error('Network error submitting order:', error);
            throw new Error('A network error occurred. Please check your connection and try again.');
        }
    }
};
