// This file is for referencing Vite-specific client types.
// It can also be used for other global type declarations.

// Fix: The type definition for 'vite/client' could not be found, causing a TypeScript error.
// This is likely a project configuration issue. Commenting out the reference to fix the build.
// /// <reference types="vite/client" />

interface Window {
  gtag: (...args: any[]) => void;
}
