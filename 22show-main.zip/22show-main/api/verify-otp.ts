import { Redis } from '@upstash/redis';
import type { VercelRequest, VercelResponse } from '@vercel/node';

// Initialize Redis client from environment variables
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL || '',
  token: process.env.UPSTASH_REDIS_REST_TOKEN || '',
});

/**
 * Normalizes an Iraqi phone number to the 9647XXXXXXXXX format.
 */
const normalizePhoneNumber = (phone: string): string => {
    const cleanedPhone = phone.replace(/\s/g, '');
    const withoutLeadingZero = cleanedPhone.startsWith('0') ? cleanedPhone.substring(1) : cleanedPhone;
    return `964${withoutLeadingZero}`;
};

export default async function handler(
  request: VercelRequest,
  response: VercelResponse,
) {
  if (request.method !== 'POST') {
    return response.status(405).json({ error: 'Method Not Allowed' });
  }

  if (!process.env.UPSTASH_REDIS_REST_URL || !process.env.UPSTASH_REDIS_REST_TOKEN) {
    console.error('Upstash Redis credentials are not configured.');
    return response.status(500).json({ error: 'Server configuration error.' });
  }
  
  const { phone, code } = request.body;

  if (!phone || !code) {
    return response.status(400).json({ error: 'Phone number and code are required.' });
  }
  
  const normalizedPhone = normalizePhoneNumber(phone);

  try {
    const key = `otp:${normalizedPhone}`;
    const storedCode = await redis.get(key);

    if (storedCode === null) {
      return response.status(400).json({ success: false, error: 'Verification code has expired or does not exist.' });
    }
    console.log(storedCode + code);
    if (storedCode == code) {
      // Correct code, delete it so it can't be reused
      await redis.del(key);
      return response.status(200).json({ success: true, message: 'Phone number verified successfully.' });
    } else {
      return response.status(400).json({ success: false, error: 'Invalid verification code6.' });
    }
  } catch (error) {
    console.error('Error verifying OTP from Redis:', error);
    return response.status(500).json({ error: 'Failed to verify OTP.' });
  }
}