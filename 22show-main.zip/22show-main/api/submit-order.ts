import type { VercelRequest, VercelResponse } from '@vercel/node';
// The 'OrderDetails' type is not available in the backend runtime,
// so we define a simplified local interface for type safety.
interface OrderDetails {
  customer: { name: string; phone: string; };
  shipping: { governorate: string; city: string; addressLine: string; };
  items: Array<{ title: string; quantity: number; price: number; }>;
  totals: { subtotal: number; deliveryFee: number; total: number; };
}

/**
 * Normalizes an Iraqi phone number to the 9647XXXXXXXXX format.
 */
const normalizePhoneNumber = (phone: string): string => {
    const cleanedPhone = phone.replace(/\s/g, '');
    const withoutLeadingZero = cleanedPhone.startsWith('0') ? cleanedPhone.substring(1) : cleanedPhone;
    return `964${withoutLeadingZero}`;
};

/**
 * Formats the order details into a clean, readable plain text message for Telegram.
 */
const formatOrderForTelegram = (orderDetails: OrderDetails): string => {
    const itemsText = orderDetails.items.map(item =>
        `  - ${item.title} (x${item.quantity}) - ${(item.price * item.quantity).toLocaleString('en-US')} دينار`
    ).join('\n');

    const message = `
New Order Received! 🛒
====================

👤 CUSTOMER DETAILS
Name: ${orderDetails.customer.name}
Phone: ${normalizePhoneNumber(orderDetails.customer.phone)}

🚚 SHIPPING ADDRESS
Governorate: ${orderDetails.shipping.governorate}
City: ${orderDetails.shipping.city}
Address: ${orderDetails.shipping.addressLine}

📦 ITEMS
${itemsText}

--------------------

💰 TOTALS
Subtotal: ${orderDetails.totals.subtotal.toLocaleString('en-US')} دينار
Delivery Fee: ${orderDetails.totals.deliveryFee.toLocaleString('en-US')} دينار
TOTAL: ${orderDetails.totals.total.toLocaleString('en-US')} دينار
    `.trim();
    return message;
};

export default async function handler(
  request: VercelRequest,
  response: VercelResponse,
) {
  if (request.method !== 'POST') {
    return response.status(405).json({ error: 'Method Not Allowed' });
  }

  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!botToken || !chatId) {
    console.error("Telegram environment variables are not configured.");
    return response.status(500).json({ error: "Order service is misconfigured." });
  }

  const { orderDetails }: { orderDetails: OrderDetails } = request.body;
  if (!orderDetails) {
    return response.status(400).json({ error: 'Order details are missing.' });
  }

  const message = formatOrderForTelegram(orderDetails);
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;

  try {
    const telegramResponse = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, text: message }),
    });

    const data = await telegramResponse.json();

    if (data.ok) {
        return response.status(200).json({ success: true });
    } else {
        console.error('Failed to send order to Telegram:', data.description);
        return response.status(500).json({ error: `Failed to send notification: ${data.description}` });
    }
  } catch (error) {
    console.error('Network error submitting order to Telegram:', error);
    return response.status(500).json({ error: 'A network error occurred.' });
  }
}