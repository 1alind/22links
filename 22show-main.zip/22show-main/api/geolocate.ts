import type { VercelRequest, VercelResponse } from '@vercel/node';

export default function handler(
  request: VercelRequest,
  response: VercelResponse,
) {
  if (request.method !== 'GET') {
    response.setHeader('Allow', ['GET']);
    return response.status(405).json({ error: 'Method Not Allowed' });
  }

  // Vercel populates this header with the country code of the requester.
  // https://vercel.com/docs/edge-network/headers#x-vercel-ip-country
  const country = request.headers['x-vercel-ip-country'] || null;
  
  // For local development, this header won't exist. We can default to 'IQ' 
  // to allow for easy testing of the shop functionality.
  const finalCountry = process.env.NODE_ENV === 'development' ? 'IQ' : country;

  return response.status(200).json({ country: finalCountry });
}
