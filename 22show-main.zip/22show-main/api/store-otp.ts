import type { VercelRequest, VercelResponse } from '@vercel/node';

export default function handler(
  request: VercelRequest,
  response: VercelResponse,
) {
  // This endpoint is currently unused.
  return response.status(404).json({ error: 'Endpoint not implemented' });
}