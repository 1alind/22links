import { Redis } from '@upstash/redis';
import type { VercelRequest, VercelResponse } from '@vercel/node';

// Initialize Redis client from environment variables
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL || '',
  token: process.env.UPSTASH_REDIS_REST_TOKEN || '',
});

// OTPs will expire in 5 minutes (300 seconds)
const OTP_EXPIRATION_SECONDS = 300; 

// Helper to generate a random 4-digit code
const generateVerificationCode = (): string => {
  return Math.floor(1000 + Math.random() * 9000).toString();
};

/**
 * Normalizes an Iraqi phone number to the 9647XXXXXXXXX format.
 */
const normalizePhoneNumber = (phone: string): string => {
    const cleanedPhone = phone.replace(/\s/g, '');
    const withoutLeadingZero = cleanedPhone.startsWith('0') ? cleanedPhone.substring(1) : cleanedPhone;
    return `964${withoutLeadingZero}`;
};

export default async function handler(
  request: VercelRequest,
  response: VercelResponse,
) {
  if (request.method !== 'POST') {
    return response.status(405).json({ error: 'Method Not Allowed' });
  }

  // --- Validate server configuration ---
  if (!process.env.UPSTASH_REDIS_REST_URL || !process.env.UPSTASH_REDIS_REST_TOKEN) {
    console.error('Upstash Redis credentials are not configured.');
    return response.status(500).json({ error: 'Server configuration error.' });
  }
  const authToken = process.env.OTPIQ_TOKEN;
  if (!authToken) {
    console.error("OTPIQ_TOKEN is not configured. Cannot send OTP.");
    return response.status(500).json({ error: 'The verification service is currently unavailable.' });
  }

  // --- Validate request body ---
  const { phone, method } = request.body;
  if (!phone || !method || !['sms', 'whatsapp'].includes(method)) {
    return response.status(400).json({ error: 'A valid phone number and method (sms/whatsapp) are required.' });
  }

  const normalizedPhone = normalizePhoneNumber(phone);
  const codeToSend = generateVerificationCode();
  
  const provider = method === 'whatsapp' ? 'whatsapp-sms' : 'sms';

  try {
    // --- Step 1: Send the code via OTPIQ ---
    const otpiqResponse = await fetch(
      'https://api.otpiq.com/api/sms',
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${authToken}`,
          'Content-Type': 'application/json',
          
        },
        body: JSON.stringify({
          phoneNumber: normalizedPhone,
          smsType: "verification",
          provider: provider,
          // We send our generated code, but will trust the API response
          // as the source of truth for what was actually sent.
          verificationCode: codeToSend,
        }),
      }
    );

    const responseData = await otpiqResponse.json();

    if (!otpiqResponse.ok) {
        const errorMessage = responseData.error || responseData.message || 'Failed to send verification code.';
        console.error('Error sending OTP via OTPIQ:', errorMessage, responseData);
        throw new Error(errorMessage);
    }
    
    // --- Step 2: Determine the correct code and store it ---
    // Many OTP services return the code they sent in the response body.
    // We prioritize that, otherwise we fall back to the one we generated.
    const finalVerificationCode = responseData.verificationCode || responseData.code || codeToSend;

    const key = `otp:${normalizedPhone}`;
    await redis.set(key, String(finalVerificationCode), { ex: OTP_EXPIRATION_SECONDS });


    return response.status(200).json({ success: true, message: 'Verification code sent.' });

  } catch (error) {
    console.error('Error in send-verification handler:', error);
    // Return the specific error message if it's an Error instance.
    const message = error instanceof Error ? error.message : 'An unexpected server error occurred.';
    return response.status(500).json({ error: message });
  }
}