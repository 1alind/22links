
import type { Product } from './src/types';

// --- FEATURE FLAGS ---
export const SHOP_ENABLED = true; // <-- Main switch for the shop. Set to false to disable.
export const SHOW_SHOP_BUTTON = false; // <-- Set to false to completely hide the shop button from the main screen.
export const SHOW_SHOP_ALERT = false; // <-- Set to false to disable the initial heads-up alert in the shop.
export const GEOLOCATION_ENABLED = false; // <-- Set to false to disable Iraq-only shop restriction.

// --- GEOLOCATION ---
export const ALLOWED_COUNTRY_CODE = 'IQ'; // The country code for which the shop is available.

// --- API ENDPOINTS ---
// The frontend now communicates with our own backend API endpoints,
// which securely handle interactions with external services.
export const API_ENDPOINTS = {
  // No public-facing endpoints are needed here anymore.
};

// --- SECURE ENVIRONMENT VARIABLES ---
// IMPORTANT: The following tokens must be set as Environment Variables
// in your Vercel project settings. They are used by the backend serverless functions
// and are NOT exposed to the frontend.
//
// - OTPIQ_TOKEN: Your secret token for the OTPIQ verification service.
// - TELEGRAM_BOT_TOKEN: Your secret token for your Telegram bot.
// - TELEGRAM_CHAT_ID: The ID of the Telegram chat to send order notifications to.


// --- SHOP DATA ---
export const DELIVERY_FEE = 5000;

export const PRODUCTS: { watches: Product[], perfumes: Product[] } = {
  watches: [
    { 
      id: 10, 
      title: {
          en: 'Classic Chronograph Watch',
          ar: 'ساعة كرونوغراف كلاسيكية',
          ku: 'ساعەتا کرۆنۆگراف یا کلاسیک'
      }, 
      price: 350000, 
      image: 'https://picsum.photos/seed/watchA/400/600',
      description: {
          en: 'A timeless masterpiece of precision and style. This chronograph watch features a stainless steel case, a sophisticated black dial with three sub-dials, and a genuine leather strap. Water-resistant and built to last, it\'s the perfect accessory for both formal events and everyday elegance.',
          ar: 'تحفة فنية خالدة من الدقة والأناقة. تتميز ساعة الكرونوغراف هذه بهيكل من الفولاذ المقاوم للصدأ، وميناء أسود متطور بثلاثة أقراص فرعية، وحزام من الجلد الطبيعي. مقاومة للماء ومصممة لتدوم، إنها الإكسسوار المثالي للمناسبات الرسمية والأناقة اليومية.',
          ku: 'شاهکارەکا بێ وەخت ژ وردبینی و شێوازێ. ئەڤ ساعەتا کرۆنۆگرافێ قاپەک ژ پۆلایێ ژەنگنەگر، دیالەکا رەش یا پێشکەفتی ب سێ سوب-دیالان، و قاییشەکا چەرمێ ئەسلی بخۆڤە دگریت. ل هەمبەر ئاڤێ خۆڕاگرە و بۆ مانێ هاتیە چێکرن، ئەڤە ئیکسسوارەکێ تەمامە چ بۆ هەلکەفتێن فەرمی یان ژی بۆ جوانیا رۆژانە.'
      }
    },
    { 
      id: 11, 
      title: {
          en: 'Minimalist Leather Watch',
          ar: 'ساعة جلدية بسيطة',
          ku: 'ساعەتا چەرم یا مینیمالیست'
      }, 
      price: 250000, 
      image: 'https://picsum.photos/seed/watchB/400/600',
      description: {
          en: 'Embrace simplicity with our Minimalist Leather Watch. Featuring a clean, uncluttered face with slim markers and a soft, supple leather band, this piece is the epitome of modern sophistication. Its lightweight design ensures maximum comfort for all-day wear.',
          ar: 'احتضن البساطة مع ساعتنا الجلدية البسيطة. تتميز بوجه نظيف وغير مزدحم بعلامات رفيعة وحزام جلدي ناعم ومرن، هذه القطعة هي مثال للرقي الحديث. يضمن تصميمها خفيف الوزن أقصى درجات الراحة للارتداء طوال اليوم.',
          ku: 'سادەییێ ب ساعەتا مە یا چەرمێ مینیمالیست هەمبێز بکە. ب روویەکێ پاقژ و نەقەرەبالغ ب نیشانکەرێن تنک و قاییشەکا چەرمێ نەرم و لیس، ئەڤ پارچە نموونەیا سوفیستیکەیا مۆدێرنە. دیزاینا وێ یا سڤک راحەتیا ماکسیمم بۆ لبەرکرنا تماما رۆژێ مسۆگەر دکەت.'
      }
    },
    { 
      id: 12, 
      title: {
          en: 'Digital Sport Watch',
          ar: 'ساعة رياضية رقمية',
          ku: 'ساعەتا وەرزشی یا دیجیتال'
      }, 
      price: 175000, 
      image: 'https://picsum.photos/seed/watchC/400/600',
      description: {
          en: 'Engineered for the active man, this Digital Sport Watch is both rugged and functional. It includes a stopwatch, alarm, backlit display, and a durable silicone strap. Its shock-resistant and water-resistant construction makes it the ideal companion for any adventure.',
          ar: 'صُممت هذه الساعة الرياضية الرقمية للرجل النشط، وهي متينة وعملية. تشتمل على ساعة توقيت، ومنبه، وشاشة بإضاءة خلفية، وحزام سيليكون متين. هيكلها المقاوم للصدمات والماء يجعلها الرفيق المثالي لأي مغامرة.',
          ku: 'ئەڤ ساعەتا وەرزشی یا دیجیتال بۆ زەلامێ چالاک هاتیە دیزاینکرن، هەم یا خۆڕاگرە و هەم یا فەنکشنالە. ستۆپواچ، ئالارم، شاشەیا ب رووناهیا پاشی، و قاییشەکا سلیکۆنێ یا بەردەوام بخۆڤە دگریت. پێکهاتەیا وێ یا دژی شۆک و ئاڤێ وێ دکەتە هەڤالێ نموونەیی بۆ هەر سەرکێشیەکێ.'
      }
    },
    { 
      id: 13, 
      title: {
          en: 'Luxury Steel Watch',
          ar: 'ساعة فولاذية فاخرة',
          ku: 'ساعەتا پۆلایێ لوکس'
      }, 
      price: 650000, 
      image: 'https://picsum.photos/seed/watchD/400/600',
      description: {
          en: 'Make a bold statement with this Luxury Steel Watch. Crafted from premium, polished stainless steel, it features an automatic movement and a striking blue sunray dial. The integrated steel bracelet provides a seamless and comfortable fit, exuding confidence and power.',
          ar: 'عبّر عن نفسك بجرأة مع هذه الساعة الفولاذية الفاخرة. مصنوعة من الفولاذ المقاوم للصدأ المصقول عالي الجودة، وتتميز بحركة أوتوماتيكية وميناء أزرق مذهل بنمط أشعة الشمس. يوفر السوار الفولاذي المدمج ملاءمة سلسة ومريحة، مما يمنحك الثقة والقوة.',
          ku: 'ب ڤێ ساعەتا پۆلایێ لوکس داخویانیەکا ب جەرئەت بدە. ژ پۆلایێ ژەنگنەگرێ پرێمیەم و پۆلیشکری هاتیە چێکرن، مەکینەیەکا ئۆتۆماتیک و دیالەکا شین یا تیشک-رۆژێ یا بەرچاڤ بخۆڤە دگریت. بازنێ پۆلایی یێ ئینتەگرەکری لێهاتنەکا بێ درز و راحەت دابین دکەت، کو باوەری و هێزێ دەر دبرت.'
      }
    },
  ],
  perfumes: [
      { 
        id: 20, 
        title: {
            en: 'Oud & Bergamot Elixir',
            ar: 'إكسير العود والبرغموت',
            ku: 'ئیلکسیرێ عود و بێرگامۆت'
        }, 
        price: 125000, 
        image: 'https://picsum.photos/seed/perfumeA/400/600',
        description: {
            en: 'An intoxicating blend of smoky oud wood and crisp bergamot. This elixir is a mysterious and captivating scent, with warm, woody base notes and a hint of citrus. Perfect for evening wear, it leaves a memorable and distinguished trail.',
            ar: 'مزيج ساحر من خشب العود المدخن والبرغموت المنعش. هذا الإكسير هو عطر غامض وجذاب، مع نفحات أساسية خشبية دافئة ولمسة من الحمضيات. مثالي للمساء، يترك أثراً لا يُنسى ومميزاً.',
            ku: 'تێکەلەکا سەرخوەشکەر ژ دارا عودا دکێشای و بێرگامۆتا تژ. ئەڤ ئیلکسیرە بێهنەکا نهێنی و دلکێشە، ب نۆتێن بنەرەتی یێن گەرم و دارینی و تیشکەکا ستروسی. تەمامە بۆ لبەرکرنا ئێڤاران، رێچەکا ب بیرمان و بەرنیاس ل پاش خۆ دهێلیت.'
        }
      },
      { 
        id: 21, 
        title: {
            en: 'Santal Noir Parfum',
            ar: 'عطر سانتال نوار',
            ku: 'پارفوما سانتال نوار'
        }, 
        price: 150000, 
        image: 'https://picsum.photos/seed/perfumeB/400/600',
        description: {
            en: 'Rich, creamy, and sensual, Santal Noir is a tribute to the sacred sandalwood. Notes of cardamom, iris, and violet add a spicy, leathery depth, creating a fragrance that is both comforting and addictive. A modern classic for the discerning gentleman.',
            ar: 'غني، كريمي، وحسي، سانتال نوار هو تكريم لخشب الصندل المقدس. تضيف نفحات الهيل، السوسن، والبنفسج عمقًا حارًا وجلديًا، مما يخلق عطرًا مريحًا وإدمانيًا في آن واحد. كلاسيكي حديث للرجل المميز.',
            ku: 'زەنگین، کرێمی، و هەستیار، سانتال نوار رێزگرتنەکە ل دارا سەندەلێ یا پیرۆز. نۆتێن هێلێ، ئایریس، و ڤیۆلێتێ کووراتیەکا ب بـهارات و چەرمی زێدە دکەن، و بێهنەکێ دروست دکەن کو هەم ئارامبەخشە و هەم ئالودەکەرە. کلاسیکەکا مۆدێرن بۆ جەنابێ ژیر.'
        }
      },
      { 
        id: 22, 
        title: {
            en: 'Aqua Marine Cologne',
            ar: 'كولونيا أكوا مارين',
            ku: 'کۆلۆنیا ئاکوا مارین'
        }, 
        price: 110000, 
        image: 'https://picsum.photos/seed/perfumeC/400/600',
        description: {
            en: 'Capture the essence of the ocean with Aqua Marine. This fresh and invigorating cologne combines notes of sea salt, grapefruit, and ambergris to create a clean, aquatic scent. It\'s the perfect choice for a fresh start to your day or a weekend getaway.',
            ar: 'استحضر جوهر المحيط مع أكوا مارين. تجمع هذه الكولونيا المنعشة والحيوية بين نفحات ملح البحر، الجريب فروت، والعنبر لخلق رائحة مائية نظيفة. إنها الخيار الأمثل لبداية منعشة ليومك أو لعطلة نهاية الأسبوع.',
            ku: 'جەوهەرێ ئۆقیانوسێ ب ئاکوا مارین بگرە. ئەڤ کۆلۆنیایا فرێش و زیندی کەر تێکەلەکا نۆتێن خویا دەریایێ، گرەیپفروت، و عەنبەرێ یە بۆ دروستکرنا بێهنەکا پاقژ و ئاڤی. ئەڤە هەلبژارتنەکا تەمامە بۆ دەستپێکەکا نوو بۆ رۆژا تە یان بۆ گەشتەکا دوماهیا حەفتیێ.'
        }
      },
      { 
        id: 23, 
        title: {
            en: 'Spiced Vetiver',
            ar: 'فيتيفر بالتوابل',
            ku: 'ڤێتیڤەرێ ب بـهارات'
        }, 
        price: 140000, 
        image: 'https://picsum.photos/seed/perfumeD/400/600',
        description: {
            en: 'Earthy, woody, and slightly sweet, Spiced Vetiver is a sophisticated fragrance with a powerful character. The grounding aroma of vetiver is enhanced by a warm blend of black pepper, nutmeg, and a touch of vanilla, resulting in a scent that is both masculine and refined.',
            ar: 'ترابي، خشبي، وحلو قليلاً، فيتيفر بالتوابل هو عطر متطور ذو طابع قوي. يتم تعزيز رائحة الفيتيفر المهدئة بمزيج دافئ من الفلفل الأسود، جوزة الطيب، ولمسة من الفانيليا، مما ينتج عنه رائحة ذكورية وأنيقة.',
            ku: 'ئەردی، دارینی، و کێمەک شرین، ڤێتیڤەرێ ب بـهارات بێهنەکا سوفیستیکەیە ب کارەکتەرەکێ بهێز. بێهنا ڤێتیڤەرێ یا ئارامکەر ب تێکەلەکا گەرم ژ بیبەرا رەش، جەوزا بۆیا، و تیشکەکا ڤانیلایێ هاتیە بهێزکرن، کو د ئەنجام دا بێهنەکا هەم مێرانە و هەم سافی دەر دکەڤیت.'
        }
      },
  ]
};

// --- LOCATION DATA ---
// Moved from Cart.tsx to be centrally managed.
export const IRAQI_LOCATIONS = {
    'Al Anbar': ['Ramadi', 'Fallujah', 'Hit', 'Haditha', 'Al-Qa\'im', 'Rutba', 'Anah', 'Rawah', 'Khalidiyah'],
    'Babil': ['Hillah', 'Musayyib', 'Mahaweel', 'Al-Hashimiya'],
    'Baghdad': ['Rusafa', 'Adhamiyah', 'Sadr City', 'Karkh', 'Kadhimiya', 'Mansour', 'Mahmudiyah', 'Abu Ghraib', 'Al-Mada\'in', 'Taji'],
    'Basra': ['Basra', 'Shatt Al-Arab', 'Al-Qurnah', 'Al-Zubair', 'Abu Al-Khaseeb', 'Faw', 'Al-Midaina'],
    'Dhi Qar': ['Nasiriyah', 'Al-Shatrah', 'Al-Rifai', 'Suq al-Shuyukh', 'Al-Chibayish', 'Qalat Sukkar', 'Al-Dawayah', 'Al-Fuhood', 'Al-Batha'],
    'Al-Qadisiyyah': ['Al Diwaniyah', 'Al-Shamiya', 'Afak', 'Hamza', 'Al-Sadir', 'Shannafiya'],
    'Diyala': ['Baqubah', 'Muqdadiyah', 'Al-Khalis', 'Khanaqin', 'Balad Ruz', 'Kifri'],
    'Duhok': ['Duhok', 'Amedi', 'Zakho', 'Akre', 'Semel', 'Bardarash', 'Shekhan'],
    'Erbil': ['Erbil', 'Koya', 'Rawanduz', 'Soran', 'Shaqlawa', 'Choman', 'Khabat', 'Mergasor', 'Dashti Hawler'],
    'Halabja': ['Halabja', 'Sharazur', 'Penjwen', 'Said Sadiq', 'Byara', 'Sirwan', 'Khurmal'],
    'Karbala': ['Karbala', 'Al-Hindiya', 'Ain Al-Tamur'],
    'Kirkuk': ['Kirkuk', 'Hawija', 'Daquq', 'Dibs'],
    'Maysan': ['Amarah', 'Ali Al-Gharbi', 'Al-Mejar Al-Kabi', 'Qal\'at Saleh', 'Al-Kahla', 'Al-Maimouna'],
    'Muthanna': ['Samawah', 'Rumaitha', 'Al-Khidhir', 'Al- Salman'],
    'Najaf': ['Najaf', 'Kufa', 'Al-Manathera', 'Al-Mishkhab'],
    'Nineveh': ['Mosul', 'Tal Afar', 'Al-Hamdaniya', 'Shekhan', 'Sinjar', 'Tel Kaif', 'Akre', 'Hatra', 'Al-Ba\'aj'],
    'Saladin': ['Tikrit', 'Samarra', 'Balad', 'Baiji', 'Al-Shirqat', 'Al-Daur', 'Tuz Khurmatu', 'Dujail', 'Al-Alam', 'Dhuluiya'],
    'Sulaymaniyah': ['Sulaymaniyah', 'Chamchamal', 'Ranya', 'Pishdar', 'Dokan', 'Darbandikhan', 'Kalar', 'Sharbazher', 'Mawat', 'Qaradagh'],
    'Wasit': ['Kut', 'Al-Suwaira', 'Al-Hai', 'Al-Numaniyah', 'Badra', 'Aziziyah'],
};
