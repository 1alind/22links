
import React, { useState, useEffect } from 'react';

const Background: React.FC = () => {
  const [mousePosition, setMousePosition] = useState({ x: -1000, y: -1000 });

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      setMousePosition({ x: event.clientX, y: event.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  // Fix: Cast the style object to React.CSSProperties to allow for CSS custom properties.
  const spotlightStyle = {
    '--mouse-x': `${mousePosition.x}px`,
    '--mouse-y': `${mousePosition.y}px`,
    position: 'absolute',
    left: 'var(--mouse-x)',
    top: 'var(--mouse-y)',
    transform: 'translate(-50%, -50%)',
    pointerEvents: 'none',
    background: 'radial-gradient(circle 600px, rgba(245, 158, 11, 0.08) 0%, transparent 60%)',
  } as React.CSSProperties;

  return (
    <div
      className="fixed inset-0 z-10" /* Keep grid above the body::before grain */
      style={{
        backgroundImage: `
          linear-gradient(rgba(255, 255, 255, 0.05) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255, 255, 255, 0.05) 1px, transparent 1px)
        `,
        backgroundSize: '30px 30px',
      }}
    >
      <div className="absolute inset-0" style={spotlightStyle} />
    </div>
  );
};

export default Background;