
import React from 'react';
import Icon from './Icon';
import { trackEvent } from '../src/analytics';

interface LinkButtonProps {
  title: string;
  url: string;
  icon: string;
  isAnimating: boolean;
  onAnimationEnd: () => void;
}

const LinkButton: React.FC<LinkButtonProps> = ({ title, url, icon, isAnimating, onAnimationEnd }) => {
  const handleClick = () => {
    trackEvent('select_content', {
      content_type: 'link',
      item_id: title,
    });
  };
  
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      onClick={handleClick}
      className="relative group flex items-center justify-center w-full bg-white/5 backdrop-blur-sm border border-white/10 text-white text-center py-3 px-4 md:p-4 rounded-lg shadow-lg transition-all duration-300 ease-in-out hover:bg-white/10 hover:border-amber-400 hover:scale-105 hover:shadow-xl hover:shadow-amber-500/10 focus:outline-none focus:ring-2 focus:ring-amber-400/50 overflow-hidden"
    >
      {/* Shimmer Animation */}
      <span
        className={`absolute inset-0 -translate-x-full transform -skew-x-12 bg-gradient-to-r from-transparent via-white/10 to-transparent ${isAnimating ? 'animate-shimmer' : ''}`}
        onAnimationEnd={isAnimating ? onAnimationEnd : undefined}
      ></span>
      
      <div className="absolute z-10 left-4 top-1/2 -translate-y-1/2">
        <Icon name={icon} />
      </div>
      <span className="relative z-10 font-semibold text-sm md:text-lg">{title}</span>
    </a>
  );
};

export default LinkButton;