
import React, { useRef, useState, useEffect } from 'react';
// FIX: Import Product and Language types from the correct path to match the data structure from config.ts.
import type { Product, Language } from '../src/types';
import { PRODUCTS } from '../config';
import { languageOptions } from '../types';

interface ShopProps {
  onClose: () => void;
  onProductAdded: (product: Product, imageElement: HTMLImageElement) => void;
  animatingProductId: number | null;
  language: Language;
  onLanguageChange: (lang: Language) => void;
}

// --- TRANSLATIONS ---
const translations = {
  en: {
    shopTitle: "22show Online 🛒 🚕",
    shopSubtitle: "we’re still in beta! If something breaks… we totally meant to do that 😌🙌",
    shopDisclaimer: "Orders from this website include only items shown here. To order other products from our shop, please reach us via WhatsApp.",
    watchesHeader: "Watches",
    perfumesHeader: "Perfumes",
    addToCartButton: "Add to Cart",
    backButton: "Back to Links",
    alertTitle: "A Quick Heads-Up!",
    alertHideButton: "I Understand",
    alertWaitMessage: "Please Read ({cooldown}s)",
  },
  ar: {
    shopTitle: "22show Online 🛒 🚕",
    shopSubtitle: "نحن لا نزال في المرحلة التجريبية! إذا حدث خطأ ما... فقد كان مقصودًا تمامًا 😌🙌",
    shopDisclaimer: "الطلبات من هذا الموقع تشمل فقط المنتجات المعروضة هنا. لطلب منتجات أخرى من متجرنا، يرجى التواصل معنا عبر الواتساب.",
    watchesHeader: "ساعات",
    perfumesHeader: "عطور",
    addToCartButton: "أضف إلى السلة",
    backButton: "العودة للروابط",
    alertTitle: "تنبيه سريع!",
    alertHideButton: "فهمت",
    alertWaitMessage: "يرجى القراءة ({cooldown} ثانية)",
  },
  ku: {
    shopTitle: "22show Online 🛒 🚕",
    shopSubtitle: "ئەم هێشتا د قۆناغا بێتاداین! ئەگەر تشتەک خراب بوو... مە ب قەست وەسا کریە 😌🙌",
    shopDisclaimer: "داخازیێن ژ ڤێ مالپەرێ بتنێ وان بەرهەمێن ل ڤێرێ دیار دگرنە خۆ. بۆ داخازکرنا بەرهەمێن دی ژ جوهانا مە، هیڤی دکەین ب رێکا واتسئاپێ پەیوەندیێ ب مە بکەن.",
    watchesHeader: "دەمژمێر",
    perfumesHeader: "عطور",
    addToCartButton: "زێدەنکە بو سەلکێ",
    backButton: "بزڤرە بۆ لینکان",
    alertTitle: "ئاگاداریەکا بلەز!",
    alertHideButton: "تێگەهشتم",
    alertWaitMessage: "هیڤی دکەم بخوینە ({cooldown} چرکە)",
  }
};

const { watches, perfumes } = PRODUCTS;


// --- Moved ShopAlert outside of Shop component to prevent re-mounting on every render ---
const ShopAlert: React.FC<{
  t: typeof translations.en;
  hideButtonCooldown: number;
  onCloseAlert: () => void;
}> = ({ t, hideButtonCooldown, onCloseAlert }) => (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in p-4">
        <div
            className="relative bg-black/50 border border-amber-500/30 rounded-xl p-6 md:p-8 max-w-lg w-full text-center shadow-2xl shadow-amber-900/20"
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="alert-title"
            aria-describedby="alert-description"
        >
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-amber-500/10 mb-4 border border-amber-500/20">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
            </div>
            <h3 id="alert-title" className="text-xl md:text-2xl font-bold text-white mb-3">{t.alertTitle}</h3>
            <div id="alert-description" className="space-y-4 text-sm md:text-base text-gray-300">
                <p className="font-semibold">{t.shopSubtitle}</p>
                <p className="text-gray-400">{t.shopDisclaimer}</p>
            </div>
            <button
                onClick={onCloseAlert}
                disabled={hideButtonCooldown > 0}
                className={`w-full md:w-auto mt-8 px-8 py-3 text-sm font-bold rounded-lg transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black/50 ${
                    hideButtonCooldown > 0 
                    ? 'bg-gray-700 text-gray-400 cursor-not-allowed' 
                    : 'bg-gradient-to-r from-amber-500 to-amber-600 text-black hover:from-amber-400 hover:to-amber-500 shadow-lg shadow-amber-500/20'
                }`}
            >
                {hideButtonCooldown > 0
                    ? t.alertWaitMessage.replace('{cooldown}', String(hideButtonCooldown))
                    : t.alertHideButton
                }
            </button>
        </div>
    </div>
);


const Shop: React.FC<ShopProps> = ({ onClose, onProductAdded, animatingProductId, language, onLanguageChange }) => {
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'ku';

  const [isAlertVisible, setIsAlertVisible] = useState(true);
  const [hideButtonCooldown, setHideButtonCooldown] = useState(10);

  useEffect(() => {
    if (!isAlertVisible || hideButtonCooldown <= 0) return;

    const timer = setTimeout(() => {
        setHideButtonCooldown(prev => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [hideButtonCooldown, isAlertVisible]);

  // FIX: Update ProductCard to accept language prop for multilingual titles and prices.
  const ProductCard: React.FC<{ product: Product; onProductAdded: (product: Product, imageElement: HTMLImageElement) => void; isAnimating: boolean; buttonText: string; language: Language; }> = ({ product, onProductAdded, isAnimating, buttonText, language }) => {
    const imgRef = useRef<HTMLImageElement>(null);

    const handleAddToCart = () => {
      if (imgRef.current) {
        onProductAdded(product, imgRef.current);
      }
    };

    return (
        <div
        key={product.id}
        className="relative bg-black/20 backdrop-blur-sm border border-gray-800 rounded-lg p-3 flex flex-col items-center justify-between aspect-[3/4] overflow-hidden transition-all duration-300"
        >
        <div className="w-full h-2/3 mb-2 rounded-md overflow-hidden">
            <img
            ref={imgRef}
            src={product.image}
            alt={product.title[language]}
            className={`w-full h-full object-cover duration-300 ease-in-out ${isAnimating ? 'opacity-0' : 'opacity-100 transition-opacity duration-300 ease-in-out'}`}
            />
        </div>
        <div className="text-center w-full flex flex-col flex-grow justify-between">
            <div>
                <h3 className="font-semibold text-xs md:text-sm text-gray-300 truncate">
                {product.title[language]}
                </h3>
                {/* FIX: Format price correctly for Iraqi Dinar. */}
                <p className="text-sm font-medium text-white mt-1">{product.price.toLocaleString('en-US')} دينار</p>
            </div>
            <button
                onClick={handleAddToCart}
                className="w-full mt-2 bg-white/10 backdrop-blur-md text-white text-xs font-bold py-2 px-3 rounded-lg transition-colors duration-300 ease-in-out hover:bg-white/20 flex items-center justify-center"
            >
                {buttonText}
            </button>
        </div>
        </div>
    );
  };

  return (
    <main
      className="relative z-20 flex flex-col items-center w-full max-w-4xl mx-auto animate-fade-in"
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      {isAlertVisible && <ShopAlert t={t} hideButtonCooldown={hideButtonCooldown} onCloseAlert={() => setIsAlertVisible(false)} />}

      <header className="mb-10 md:mb-12 w-full text-center">
        <h2 className="text-3xl md:text-4xl font-bold text-white" dir="rtl">{t.shopTitle}</h2>
        <div className="mt-6 flex justify-center items-center gap-2 md:gap-4">
          {Object.entries(languageOptions).map(([lang, { name, flag }]) => (
            <button
              key={lang}
              onClick={() => onLanguageChange(lang as Language)}
              className={`flex items-center justify-center gap-2 px-3 md:px-4 py-2 text-sm font-semibold rounded-lg transition-colors duration-200 ${
                language === lang
                  ? 'bg-amber-500 text-black'
                  : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10'
              }`}
            >
              <img src={flag} alt={`${name} flag`} className="w-5 h-auto rounded-sm" />
              <span>{name}</span>
            </button>
          ))}
        </div>
        <div className="mt-6 max-w-2xl mx-auto text-center bg-black/20 border border-gray-800 rounded-lg p-4 space-y-2">
            <p className="text-sm md:text-base text-gray-300 font-semibold">{t.shopSubtitle}</p>
            <p className="text-xs md:text-sm text-gray-400">{t.shopDisclaimer}</p>
        </div>
      </header>
      
      {/* Watches Section */}
      <section className="w-full mb-10 md:mb-12">
        <h3 className={`text-xl md:text-2xl font-semibold text-white mb-4 md:mb-6 ${isRtl ? 'text-right' : 'text-left'} px-2 md:px-0`}>{t.watchesHeader}</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 w-full">
            {watches.map((product) => (
                // FIX: Pass language prop to ProductCard.
                <ProductCard key={product.id} product={product} onProductAdded={onProductAdded} isAnimating={animatingProductId === product.id} buttonText={t.addToCartButton} language={language} />
            ))}
        </div>
      </section>
      
      {/* Perfumes Section */}
      <section className="w-full mb-10 md:mb-12">
        <h3 className={`text-xl md:text-2xl font-semibold text-white mb-4 md:mb-6 ${isRtl ? 'text-right' : 'text-left'} px-2 md:px-0`}>{t.perfumesHeader}</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 w-full">
            {perfumes.map((product) => (
                // FIX: Pass language prop to ProductCard.
                <ProductCard key={product.id} product={product} onProductAdded={onProductAdded} isAnimating={animatingProductId === product.id} buttonText={t.addToCartButton} language={language} />
            ))}
        </div>
      </section>

      <button
        onClick={onClose}
        className="bg-black/30 backdrop-blur-sm border border-gray-700 text-gray-300 py-2 px-8 rounded-lg transition-colors hover:bg-gray-800 hover:text-white focus:outline-none focus:ring-2 focus:ring-white/50"
      >
        {t.backButton}
      </button>
    </main>
  );
};

export default Shop;
