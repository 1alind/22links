
import React, { useState, useCallback, forwardRef, useRef, useEffect } from 'react';
import LinkButton from './components/LinkButton';
import Icon from './components/Icon';
import type { Link, Product, Language } from './types';
import Background from './components/Background';
import Shop from './components/ComingSoon';
import Cart from './components/Cart';
import { CartProvider, useCart } from './hooks/useCart';
import { SHOP_ENABLED } from './config';

// --- Data Constants ---
const LINKS: Link[] = [
  { id: 1, title: 'WhatsApp', url: 'https://wa.me/9647501859616', icon: 'whatsapp' },
  { id: 2, title: 'Instagram', url: 'https://instagram.com/22show_', icon: 'instagram' },
  { id: 3, title: 'TikTok', url: 'https://www.tiktok.com/@22show_', icon: 'tiktok' },
  { id: 4, title: 'Snapchat', url: 'https://t.snapchat.com/RInsrLAk', icon: 'snapchat' },
  { id: 5, title: 'Apple Maps', url: 'https://maps.apple/p/zWP3Cc9SNRqCBz', icon: 'apple-maps' },
  { id: 6, title: 'Google Maps', url: 'https://maps.app.goo.gl/G7xczmrF6BWAdxoCA', icon: 'google-maps' },
];

const EMOJI_LIST = ['👕', '👖', '👟', '🥾', '🩳', '🧦', '🧢', '🕶️', '⌚️', '🚕'];

// --- Custom Hook for animations ---
const useCyclicalAnimations = (emojiList: string[], linkCount: number) => {
  const [emojiIndex, setEmojiIndex] = useState(0);
  const [animatedLinkIndex, setAnimatedLinkIndex] = useState(0);

  const handleEmojiAnimationIteration = useCallback(() => {
    setEmojiIndex(current => current + 2);
  }, []);

  const handleShimmerAnimationEnd = useCallback(() => {
    setAnimatedLinkIndex(current => (current + 1) % linkCount);
  }, [linkCount]);

  const currentEmoji1 = emojiList[emojiIndex % emojiList.length];
  const currentEmoji2 = emojiList[(emojiIndex + 1) % emojiList.length];

  return {
    animatedLinkIndex,
    currentEmoji1,
    currentEmoji2,
    handleEmojiAnimationIteration,
    handleShimmerAnimationEnd,
  };
};

const CartIcon = forwardRef<HTMLButtonElement, { onClick: () => void, isGlowing: boolean }>(({ onClick, isGlowing }, ref) => {
    const { cart } = useCart();
    const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

    if (itemCount === 0) return null;

    return (
        <button
            ref={ref}
            onClick={onClick}
            className={`fixed top-4 right-4 z-50 bg-black/50 backdrop-blur-md p-3 rounded-full text-white border border-gray-700 hover:border-white transition-colors ${isGlowing ? 'animate-glow' : ''}`}
            aria-label={`Shopping cart with ${itemCount} items`}
        >
            <Icon name="shop" />
            <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                {itemCount}
            </span>
        </button>
    );
});


// --- App Content Component ---
const AppContent: React.FC = () => {
  const {
    animatedLinkIndex,
    currentEmoji1,
    currentEmoji2,
    handleEmojiAnimationIteration,
    handleShimmerAnimationEnd,
  } = useCyclicalAnimations(EMOJI_LIST, LINKS.length);
  
  const { cart, addToCart } = useCart();
  const [isShopVisible, setIsShopVisible] = useState(false);
  const [isCartVisible, setIsCartVisible] = useState(false);
  const [isCartGlowing, setIsCartGlowing] = useState(false);
  const [language, setLanguage] = useState<Language>('en');
  const cartIconRef = useRef<HTMLButtonElement>(null);
  const [flyingImage, setFlyingImage] = useState<{ src: string, rect: DOMRect } | null>(null);
  const flyerRef = useRef<HTMLImageElement>(null);
  const [animatingProductId, setAnimatingProductId] = useState<number | null>(null);
  const [pendingAnimation, setPendingAnimation] = useState<{ product: Product, rect: DOMRect } | null>(null);


  const handleAddToCartWithAnimation = useCallback((product: Product, imageElement: HTMLImageElement) => {
    addToCart(product);
    const startRect = imageElement.getBoundingClientRect();
    setPendingAnimation({ product, rect: startRect });
  }, [addToCart]);
  
  // Effect to START the animation once the cart icon is rendered
  useEffect(() => {
    // Trigger only when there's a pending animation AND the cart icon is ready
    if (pendingAnimation && cartIconRef.current) {
        setFlyingImage({ src: pendingAnimation.product.image, rect: pendingAnimation.rect });
        setAnimatingProductId(pendingAnimation.product.id);
        setPendingAnimation(null); // Clear the pending state
    }
  }, [pendingAnimation, cart]); // depends on cart to re-run when cart icon appears

  // Effect for the "fly to cart" animation
  useEffect(() => {
    if (!flyingImage || !flyerRef.current || !cartIconRef.current) return;

    const flyer = flyerRef.current;
    const endRect = cartIconRef.current.getBoundingClientRect();

    // Animate flyer to the cart icon
    requestAnimationFrame(() => {
        flyer.style.left = `${endRect.left + endRect.width / 2 - flyingImage.rect.width / 4}px`;
        flyer.style.top = `${endRect.top + endRect.height / 2 - flyingImage.rect.height / 4}px`;
        flyer.style.width = '20px';
        flyer.style.height = '20px';
        flyer.style.opacity = '0';
        flyer.style.transform = 'scale(0.2) rotate(180deg)';
    });
    
    // Using a timer that matches the CSS transition duration is more reliable
    // than using the 'transitionend' event, which can fire multiple times.
    const animationTimer = setTimeout(() => {
      setFlyingImage(null); // Clean up DOM element
      setIsCartGlowing(true); // Trigger glow effect
      setAnimatingProductId(null); // Reset the animating product
    }, 700); // 0.7s, matching the .fly-to-cart transition

    return () => clearTimeout(animationTimer);
  }, [flyingImage]);

  // Effect for the cart glowing animation
  useEffect(() => {
    if (isCartGlowing) {
      const glowTimer = setTimeout(() => {
        setIsCartGlowing(false);
      }, 1000); // 1s, matching the .animate-glow animation
      return () => clearTimeout(glowTimer);
    }
  }, [isCartGlowing]);

  return (
    <div className="relative min-h-screen w-full bg-transparent text-white flex flex-col items-center justify-center px-4 py-8 font-sans overflow-hidden">
      <Background />
      {/* The flyer element for animation */}
      {flyingImage && (
          <img
              ref={flyerRef}
              src={flyingImage.src}
              className="fly-to-cart"
              style={{
                  top: `${flyingImage.rect.top}px`,
                  left: `${flyingImage.rect.left}px`,
                  width: `${flyingImage.rect.width}px`,
                  height: `${flyingImage.rect.height}px`,
              }}
              alt=""
          />
      )}
      {isShopVisible && <CartIcon ref={cartIconRef} onClick={() => setIsCartVisible(true)} isGlowing={isCartGlowing} />}
      <Cart isVisible={isCartVisible} onClose={() => setIsCartVisible(false)} language={language} />
      
      {isShopVisible ? (
        <Shop onClose={() => setIsShopVisible(false)} onProductAdded={handleAddToCartWithAnimation} animatingProductId={animatingProductId} language={language} onLanguageChange={setLanguage} />
      ) : (
        <main className="relative z-20 flex flex-col items-center w-full max-w-md md:max-w-lg mx-auto text-center animate-fade-in">
          <header className="mb-10 md:mb-12 flex flex-col items-center">
            <img
              src="https://1alind.sirv.com/Images/22show_logo.jpeg"
              alt="22 Show - Men's Clothing Store in Duhok"
              className="w-20 h-20 md:w-24 md:h-24 rounded-full shadow-lg mb-4 object-cover border-2 border-white/10"
            />
            <h1 className="text-2xl md:text-4xl font-bold tracking-tight text-white flex items-center justify-center gap-2">
              <span>22 Show</span>
              <div className="emoji-slider">
                <span
                  className="emoji"
                  aria-hidden="true"
                  onAnimationIteration={handleEmojiAnimationIteration}
                >
                  {currentEmoji1}
                </span>
                <span className="emoji emoji-2" aria-hidden="true">{currentEmoji2}</span>
              </div>
            </h1>
            {/* USER-REQUESTED-TEXT: DO NOT CHANGE THESE LINES */}
            <p className="mt-2 text-sm md:text-base text-gray-400">
              بو فروتنا جل و بەرگێن گەنجان
            </p>
            <p className="mt-1 text-sm md:text-base text-gray-400">
              دهوك - تاخێ سەرهلدان، نێزیک پارکا سەرهلدان
            </p>
          </header>

          <section className="w-4/5 md:w-full space-y-4">
            {LINKS.map((link, index) => (
              <LinkButton
                key={link.id}
                title={link.title}
                url={link.url}
                icon={link.icon}
                isAnimating={animatedLinkIndex === index}
                onAnimationEnd={handleShimmerAnimationEnd}
              />
            ))}
            {SHOP_ENABLED ? (
              <div
                role="button"
                tabIndex={0}
                onClick={() => setIsShopVisible(true)}
                onKeyDown={(e) => { if (e.key === 'Enter') setIsShopVisible(true); }}
                className="relative group flex items-center justify-center w-full bg-black/30 backdrop-blur-sm border border-gray-700 text-white text-center py-3 px-4 md:p-4 rounded-lg shadow-lg transition-all duration-300 ease-in-out hover:bg-gray-800 hover:border-white hover:scale-105 focus:outline-none focus:ring-2 focus:ring-white/50 cursor-pointer"
              >
                <div className="absolute left-4 top-1/2 -translate-y-1/2">
                  <Icon name="shop" />
                </div>
                <span className="font-semibold text-sm md:text-lg">
                  Online Shop
                </span>
              </div>
            ) : (
               <div
                className="relative flex items-center justify-center w-full bg-black/20 backdrop-blur-sm border border-gray-800 text-gray-500 text-center py-3 px-4 md:p-4 rounded-lg shadow-lg cursor-not-allowed"
              >
                <div className="absolute left-4 top-1/2 -translate-y-1/2">
                  <Icon name="shop" />
                </div>
                <span className="font-semibold text-sm md:text-lg">
                  Online Shop <span className="text-xs font-normal">(Under Maintenance)</span>
                </span>
              </div>
            )}
          </section>

          <footer className="mt-8 md:mt-12">
            <p className="mt-6 text-sm text-gray-400">
              &copy; {new Date().getFullYear()} 22 Show. All Rights Reserved.
            </p>
          </footer>
        </main>
      )}
    </div>
  );
};


// --- Main App Component Wrapper ---
const App: React.FC = () => {
  return (
    <CartProvider>
      <AppContent />
    </CartProvider>
  )
}

export default App;
